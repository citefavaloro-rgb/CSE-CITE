import * as XLSX from 'xlsx';

export interface AttendanceRecord {
  studentName: string;
  studentDni?: string;
  date: string;
  status: 'presente' | 'ausente' | 'justificado' | 'tarde';
  notes?: string;
  errors?: string[];
}

export interface AttendanceImportResult {
  success: boolean;
  totalRecords: number;
  validRecords: number;
  invalidRecords: number;
  records: AttendanceRecord[];
  errors: string[];
}

/**
 * Parsea un archivo Excel de asistencias
 * Formato esperado:
 * - Columna A: Nombre del estudiante (requerido)
 * - Columna B: DNI del estudiante (opcional)
 * - Columna C: Fecha (requerido, formato DD/MM/YYYY)
 * - Columna D: Estado (requerido: presente, ausente, justificado, tarde)
 * - Columna E: Notas (opcional)
 */
export function parseAttendanceExcel(fileBuffer: Buffer): AttendanceImportResult {
  const errors: string[] = [];
  const records: AttendanceRecord[] = [];

  try {
    const workbook = XLSX.read(fileBuffer, { type: 'buffer' });
    const worksheet = workbook.Sheets[workbook.SheetNames[0]];

    if (!worksheet) {
      return {
        success: false,
        totalRecords: 0,
        validRecords: 0,
        invalidRecords: 0,
        records: [],
        errors: ['No se encontró hoja de cálculo en el archivo'],
      };
    }

    const data = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as unknown[][];

    if (data.length < 2) {
      return {
        success: false,
        totalRecords: 0,
        validRecords: 0,
        invalidRecords: 0,
        records: [],
        errors: ['El archivo debe contener al menos una fila de datos'],
      };
    }

    // Saltar encabezado
    const dataRows = data.slice(1);

    dataRows.forEach((row, rowIndex) => {
      const recordErrors: string[] = [];
      const rowNum = rowIndex + 2; // +2 porque saltamos encabezado y es 1-indexed

      // Validar que la fila no esté vacía
      if (!row || row.length === 0 || row.every(cell => !cell)) {
        return;
      }

      const studentName = String(row[0] || '').trim();
      const studentDni = row[1] ? String(row[1]).trim() : undefined;
      const dateStr = String(row[2] || '').trim();
      const statusStr = String(row[3] || '').trim().toLowerCase();
      const notes = row[4] ? String(row[4]).trim() : undefined;

      // Validar nombre del estudiante
      if (!studentName) {
        recordErrors.push(`Fila ${rowNum}: Nombre del estudiante es requerido`);
      }

      // Validar fecha
      if (!dateStr) {
        recordErrors.push(`Fila ${rowNum}: Fecha es requerida`);
      } else {
        // Intentar parsear fecha en formato DD/MM/YYYY
        const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
        const match = dateStr.match(dateRegex);

        if (!match) {
          recordErrors.push(`Fila ${rowNum}: Fecha debe estar en formato DD/MM/YYYY`);
        } else {
          const [, day, month, year] = match;
          const dayNum = parseInt(day, 10);
          const monthNum = parseInt(month, 10);
          const yearNum = parseInt(year, 10);

          if (dayNum < 1 || dayNum > 31 || monthNum < 1 || monthNum > 12) {
            recordErrors.push(`Fila ${rowNum}: Fecha inválida`);
          }

          // Validar que la fecha sea razonable (no en el futuro)
          const parsedDate = new Date(yearNum, monthNum - 1, dayNum);
          if (parsedDate > new Date()) {
            recordErrors.push(`Fila ${rowNum}: La fecha no puede ser en el futuro`);
          }
        }
      }

      // Validar estado
      const validStatuses = ['presente', 'ausente', 'justificado', 'tarde'];
      if (!statusStr) {
        recordErrors.push(`Fila ${rowNum}: Estado es requerido (presente, ausente, justificado, tarde)`);
      } else if (!validStatuses.includes(statusStr)) {
        recordErrors.push(`Fila ${rowNum}: Estado inválido. Debe ser: ${validStatuses.join(', ')}`);
      }

      records.push({
        studentName,
        studentDni,
        date: dateStr,
        status: (statusStr as any) || 'presente',
        notes,
        errors: recordErrors,
      });
    });

    const validRecords = records.filter(r => !r.errors || r.errors.length === 0);
    const invalidRecords = records.filter(r => r.errors && r.errors.length > 0);

    if (invalidRecords.length > 0) {
      errors.push(`Se encontraron ${invalidRecords.length} registros con errores de validación`);
    }

    return {
      success: invalidRecords.length === 0,
      totalRecords: records.length,
      validRecords: validRecords.length,
      invalidRecords: invalidRecords.length,
      records,
      errors,
    };
  } catch (error) {
    return {
      success: false,
      totalRecords: 0,
      validRecords: 0,
      invalidRecords: 0,
      records: [],
      errors: [`Error al procesar el archivo: ${error instanceof Error ? error.message : 'Error desconocido'}`],
    };
  }
}

/**
 * Valida y procesa registros de asistencias para guardar en la base de datos
 */
export async function processAttendanceRecords(
  records: AttendanceRecord[],
  courseId: number,
  studentMap: Map<string, number> // Mapeo de nombre/DNI a studentId
): Promise<{
  processed: number;
  failed: number;
  errors: string[];
}> {
  const errors: string[] = [];
  let processed = 0;
  let failed = 0;

  for (const record of records) {
    if (record.errors && record.errors.length > 0) {
      failed++;
      errors.push(...record.errors);
      continue;
    }

    // Buscar el estudiante por nombre o DNI
    let studentId: number | undefined;

    if (record.studentDni) {
      // Buscar por DNI primero
      studentMap.forEach((id, key) => {
        if (key.includes(record.studentDni!)) {
          studentId = id;
        }
      });
    }

    if (!studentId) {
      // Buscar por nombre
      studentMap.forEach((id, key) => {
        if (key.toLowerCase().includes(record.studentName.toLowerCase())) {
          studentId = id;
        }
      });
    }

    if (!studentId) {
      failed++;
      errors.push(`No se encontró estudiante: ${record.studentName}${record.studentDni ? ` (DNI: ${record.studentDni})` : ''}`);
      continue;
    }

    // Parsear fecha
    const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
    const match = record.date.match(dateRegex);

    if (!match) {
      failed++;
      errors.push(`Fecha inválida para ${record.studentName}: ${record.date}`);
      continue;
    }

    const [, day, month, year] = match;
    const date = new Date(parseInt(year, 10), parseInt(month, 10) - 1, parseInt(day, 10));

    // Aquí iría la lógica para guardar en la base de datos
    // Por ahora solo contamos como procesado
    processed++;
  }

  return {
    processed,
    failed,
    errors,
  };
}
