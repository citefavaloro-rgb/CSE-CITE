import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";
import { storagePut } from "./storage";
import { nanoid } from "nanoid";
import { parseExcelFile, importStudents } from "./excelImporter";
import { generateStudentsPDF, generateStudentsExcel } from "./reportGenerator";
import { notifyOwner } from "./_core/notification";

// Middleware para verificar que el usuario es admin
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== 'admin') {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'Solo administradores pueden realizar esta acción' });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============================================
  // STUDENTS ROUTER
  // ============================================
  students: router({
    list: protectedProcedure
      .input(z.object({
        year: z.number().optional(),
        division: z.string().optional(),
        shift: z.enum(["mañana", "tarde", "vespertino"]).optional(),
        search: z.string().optional(),
        hasPendingSubjects: z.boolean().optional(),
        hasRecursadas: z.boolean().optional(),
        hasIntensificadas: z.boolean().optional(),
        sortBy: z.enum(["name", "year", "approvalPercentage"]).optional(),
        sortOrder: z.enum(["asc", "desc"]).optional(),
        limit: z.number().optional(),
        offset: z.number().optional(),
      }))
      .query(async ({ input }) => {
        const students = await db.listStudents(input);
        const total = await db.countStudents(input);
        return { students, total };
      }),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const student = await db.getStudentById(input.id);
        if (!student) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Estudiante no encontrado' });
        }
        
        // Obtener materias, personas autorizadas y documentos
        const subjects = await db.getSubjectsByStudent(input.id);
        const authorizedPersons = await db.getAuthorizedPersonsByStudent(input.id);
        const documents = await db.getDocumentsByStudent(input.id);
        
        return {
          ...student,
          subjects,
          authorizedPersons,
          documents
        };
      }),

    create: protectedProcedure
      .input(z.object({
        firstName: z.string().min(1, "Nombre es requerido"),
        lastName: z.string().min(1, "Apellido es requerido"),
        dni: z.string().min(1, "DNI es requerido"),
        studentPhone: z.string().optional(),
        parentPhone: z.string().optional(),
        address: z.string().optional(),
        year: z.number().min(1).max(6),
        division: z.string().min(1),
        shift: z.enum(["mañana", "tarde", "vespertino"]),
        enrollmentBook: z.string().optional(),
        enrollmentFolio: z.string().optional(),
        approvalPercentage: z.number().min(0).max(100).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        // Verificar si ya existe un estudiante con ese DNI
        const existing = await db.getStudentByDni(input.dni);
        if (existing) {
          throw new TRPCError({ code: 'CONFLICT', message: 'Ya existe un estudiante con ese DNI' });
        }
        
        await db.createStudent({
          ...input,
          createdBy: ctx.user.id,
          updatedBy: ctx.user.id,
        });
        
        return { success: true };
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        firstName: z.string().optional(),
        lastName: z.string().optional(),
        dni: z.string().optional(),
        studentPhone: z.string().optional(),
        parentPhone: z.string().optional(),
        address: z.string().optional(),
        year: z.number().min(1).max(6).optional(),
        division: z.string().optional(),
        shift: z.enum(["mañana", "tarde", "vespertino"]).optional(),
        enrollmentBook: z.string().optional(),
        enrollmentFolio: z.string().optional(),
        approvalPercentage: z.number().min(0).max(100).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const { id, ...data } = input;
        
        // Verificar que el estudiante existe
        const student = await db.getStudentById(id);
        if (!student) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Estudiante no encontrado' });
        }
        
        // Si se está actualizando el DNI, verificar que no exista otro estudiante con ese DNI
        if (data.dni && data.dni !== student.dni) {
          const existing = await db.getStudentByDni(data.dni);
          if (existing) {
            throw new TRPCError({ code: 'CONFLICT', message: 'Ya existe un estudiante con ese DNI' });
          }
        }
        
        await db.updateStudent(id, {
          ...data,
          updatedBy: ctx.user.id,
        });
        
        return { success: true };
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteStudent(input.id);
        return { success: true };
      }),
  }),

  // ============================================
  // SUBJECTS ROUTER
  // ============================================
  subjects: router({
    create: protectedProcedure
      .input(z.object({
        studentId: z.number(),
        subjectName: z.string().min(1, "Nombre de materia es requerido"),
        year: z.number().min(1).max(6),
        status: z.enum(["pendiente", "recursada", "intensificada", "aprobada"]),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.createSubject(input);
        return { success: true };
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        subjectName: z.string().optional(),
        year: z.number().min(1).max(6).optional(),
        status: z.enum(["pendiente", "recursada", "intensificada", "aprobada"]).optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateSubject(id, data);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteSubject(input.id);
        return { success: true };
      }),

    listByStudent: protectedProcedure
      .input(z.object({ studentId: z.number() }))
      .query(async ({ input }) => {
        return await db.getSubjectsByStudent(input.studentId);
      }),
  }),

  // ============================================
  // AUTHORIZED PERSONS ROUTER
  // ============================================
  authorizedPersons: router({
    create: protectedProcedure
      .input(z.object({
        studentId: z.number(),
        firstName: z.string().min(1, "Nombre es requerido"),
        lastName: z.string().min(1, "Apellido es requerido"),
        dni: z.string().min(1, "DNI es requerido"),
        relationship: z.string().min(1, "Parentesco es requerido"),
        phone: z.string().min(1, "Teléfono es requerido"),
      }))
      .mutation(async ({ input }) => {
        await db.createAuthorizedPerson(input);
        return { success: true };
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        firstName: z.string().optional(),
        lastName: z.string().optional(),
        dni: z.string().optional(),
        relationship: z.string().optional(),
        phone: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateAuthorizedPerson(id, data);
        return { success: true };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteAuthorizedPerson(input.id);
        return { success: true };
      }),

    listByStudent: protectedProcedure
      .input(z.object({ studentId: z.number() }))
      .query(async ({ input }) => {
        return await db.getAuthorizedPersonsByStudent(input.studentId);
      }),
  }),

  // ============================================
  // DOCUMENTS ROUTER
  // ============================================
  documents: router({
    upload: protectedProcedure
      .input(z.object({
        studentId: z.number(),
        fileName: z.string(),
        fileContent: z.string(), // Base64
        fileType: z.string(),
        documentType: z.enum([
          "certificado_medico",
          "autorizacion",
          "documento_identidad",
          "excel_importacion",
          "otro"
        ]),
        description: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        // Decodificar base64
        const buffer = Buffer.from(input.fileContent, 'base64');
        
        // Generar key único para S3
        const fileKey = `students/${input.studentId}/documents/${nanoid()}-${input.fileName}`;
        
        // Subir a S3
        const { url } = await storagePut(fileKey, buffer, input.fileType);
        
        // Guardar en base de datos
        await db.createDocument({
          studentId: input.studentId,
          fileName: input.fileName,
          fileKey,
          fileUrl: url,
          fileType: input.fileType,
          fileSize: buffer.length,
          documentType: input.documentType,
          description: input.description,
          uploadedBy: ctx.user.id,
        });
        
        return { success: true, url };
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteDocument(input.id);
        return { success: true };
      }),

    listByStudent: protectedProcedure
      .input(z.object({ studentId: z.number() }))
      .query(async ({ input }) => {
        return await db.getDocumentsByStudent(input.studentId);
      }),
  }),

  // ============================================
  // STATISTICS ROUTER
  // ============================================
  statistics: router({
    dashboard: protectedProcedure
      .query(async () => {
        const stats = await db.getStudentStatistics();
        const studentsAtRisk = await db.getStudentsAtRisk(50);
        const studentsWithPending = await db.getStudentsWithPendingSubjects();
        
        return {
          ...stats,
          studentsAtRiskCount: studentsAtRisk.length,
          studentsWithPendingCount: studentsWithPending.length,
        };
      }),

    studentsAtRisk: protectedProcedure
      .input(z.object({
        threshold: z.number().min(0).max(100).optional(),
      }))
      .query(async ({ input }) => {
        return await db.getStudentsAtRisk(input.threshold || 50);
      }),
  }),

  // ============================================
  // COURSES ROUTER
  // ============================================
  courses: router({
    list: protectedProcedure
      .query(async () => {
        return await db.listCourses();
      }),

    create: adminProcedure
      .input(z.object({
        year: z.number().min(1).max(6),
        division: z.string().min(1),
        shift: z.enum(["mañana", "tarde", "vespertino"]),
        preceptorId: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.createCourse(input);
        return { success: true };
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        year: z.number().min(1).max(6).optional(),
        division: z.string().optional(),
        shift: z.enum(["mañana", "tarde", "vespertino"]).optional(),
        preceptorId: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateCourse(id, data);
        return { success: true };
      }),

    byPreceptor: protectedProcedure
      .input(z.object({ preceptorId: z.number() }))
      .query(async ({ input }) => {
        return await db.getCoursesByPreceptor(input.preceptorId);
      }),
  }),

  // ============================================
  // IMPORT ROUTER
  // ============================================
  import: router({
    parseExcel: protectedProcedure
      .input(z.object({
        fileContent: z.string(), // Base64
        fileName: z.string(),
      }))
      .mutation(async ({ input }) => {
        const buffer = Buffer.from(input.fileContent, 'base64');
        const rows = await parseExcelFile(buffer);
        return { rows, count: rows.length };
      }),

    executeImport: protectedProcedure
      .input(z.object({
        fileContent: z.string(), // Base64
        fileName: z.string(),
      }))
      .mutation(async ({ input, ctx }) => {
        const buffer = Buffer.from(input.fileContent, 'base64');
        
        // Subir archivo a S3
        const fileKey = `imports/${nanoid()}-${input.fileName}`;
        const { url } = await storagePut(fileKey, buffer, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        
        // Crear registro de importación
        const importRecord = await db.createImportHistory({
          fileName: input.fileName,
          fileKey,
          fileUrl: url,
          status: 'processing',
          importedBy: ctx.user.id,
        });
        
        const importId = Number(importRecord[0].insertId);
        
        try {
          // Parsear y importar
          const rows = await parseExcelFile(buffer);
          const result = await importStudents(rows, ctx.user.id);
          
          // Actualizar registro de importación
          await db.updateImportHistory(importId, {
            recordsImported: result.recordsImported,
            recordsFailed: result.recordsFailed,
            status: result.success ? 'completed' : 'failed',
            errorLog: result.errors.length > 0 ? JSON.stringify(result.errors) : undefined,
          });
          
          // Notificar al coordinador si hay estudiantes en riesgo
          const studentsAtRisk = await db.getStudentsAtRisk(50);
          if (studentsAtRisk.length > 0) {
            await notifyOwner({
              title: 'Alumnos en riesgo detectados',
              content: `Se han detectado ${studentsAtRisk.length} alumnos con menos del 50% de aprobación tras la importación de datos.`,
            });
          }
          
          return { ...result, importId };
        } catch (error: any) {
          // Actualizar registro como fallido
          await db.updateImportHistory(importId, {
            status: 'failed',
            errorLog: error.message,
          });
          throw error;
        }
      }),

    history: protectedProcedure
      .input(z.object({
        limit: z.number().optional(),
      }))
      .query(async ({ input }) => {
        return await db.getImportHistoryList(input.limit || 50);
      }),
  }),

  // ============================================
  // REPORTS ROUTER
  // ============================================
  reports: router({
    generatePDF: protectedProcedure
      .input(z.object({
        filters: z.object({
          year: z.number().optional(),
          division: z.string().optional(),
          shift: z.enum(["mañana", "tarde", "vespertino"]).optional(),
        }).optional(),
      }))
      .mutation(async ({ input }) => {
        const students = await db.listStudents(input.filters || {});
        const stats = await db.getStudentStatistics();
        
        const pdfBuffer = await generateStudentsPDF(students, stats);
        
        // Subir PDF a S3
        const fileKey = `reports/students-${nanoid()}.pdf`;
        const { url } = await storagePut(fileKey, pdfBuffer, 'application/pdf');
        
        return { url, fileName: `reporte-estudiantes-${Date.now()}.pdf` };
      }),

    generateExcel: protectedProcedure
      .input(z.object({
        filters: z.object({
          year: z.number().optional(),
          division: z.string().optional(),
          shift: z.enum(["mañana", "tarde", "vespertino"]).optional(),
        }).optional(),
      }))
      .mutation(async ({ input }) => {
        const students = await db.listStudents(input.filters || {});
        
        // Obtener materias para cada estudiante
        const studentsWithSubjects = await Promise.all(
          students.map(async (student) => {
            const subjects = await db.getSubjectsByStudent(student.id);
            return { ...student, subjects };
          })
        );
        
        const excelBuffer = await generateStudentsExcel(studentsWithSubjects);
        
        // Subir Excel a S3
        const fileKey = `reports/students-${nanoid()}.xlsx`;
        const { url } = await storagePut(fileKey, excelBuffer, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        
        return { url, fileName: `reporte-estudiantes-${Date.now()}.xlsx` };
      }),
  }),

  // ============================================
  // ATTENDANCES ROUTER
  // ============================================
  attendances: router({
    record: protectedProcedure
      .input(z.object({
        studentId: z.number(),
        courseId: z.number(),
        date: z.date(),
        status: z.enum(["presente", "ausente", "justificado", "tarde"]),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const attendance = await db.createAttendance({
          ...input,
          recordedBy: ctx.user.id,
        });
        
        // Notificar si es una ausencia
        if (input.status === "ausente") {
          const student = await db.getStudentById(input.studentId);
          if (student) {
            await notifyOwner({
              title: "Inasistencia registrada",
              content: `${student.lastName}, ${student.firstName} - Ausente el ${input.date.toLocaleDateString('es-AR')}`
            });
          }
        }
        
        return attendance;
      }),

    getByStudent: protectedProcedure
      .input(z.object({
        studentId: z.number(),
        startDate: z.date().optional(),
        endDate: z.date().optional(),
      }))
      .query(async ({ input }) => {
        return await db.getAttendancesByStudent(input.studentId, input.startDate, input.endDate);
      }),

    getByCourse: protectedProcedure
      .input(z.object({
        courseId: z.number(),
        startDate: z.date().optional(),
        endDate: z.date().optional(),
      }))
      .query(async ({ input }) => {
        return await db.getAttendancesByCourse(input.courseId, input.startDate, input.endDate);
      }),

    getSummary: protectedProcedure
      .input(z.object({
        studentId: z.number(),
        courseId: z.number(),
        month: z.number().min(1).max(12),
        year: z.number(),
      }))
      .query(async ({ input }) => {
        return await db.getAttendanceSummary(input.studentId, input.courseId, input.month, input.year);
      }),

    getStudentReport: protectedProcedure
      .input(z.object({ studentId: z.number() }))
      .query(async ({ input }) => {
        return await db.getStudentAbsenceReport(input.studentId);
      }),

    getCourseReport: protectedProcedure
      .input(z.object({
        courseId: z.number(),
        month: z.number().min(1).max(12).optional(),
        year: z.number().optional(),
      }))
      .query(async ({ input }) => {
        return await db.getCourseAbsenceReport(input.courseId, input.month, input.year);
      }),
    importPreview: adminProcedure
      .input(z.object({
        fileBase64: z.string(),
        courseId: z.number(),
      }))
      .mutation(async ({ input }) => {
        const { parseAttendanceExcel } = await import('./attendanceImporter');
        const buffer = Buffer.from(input.fileBase64, 'base64');
        const result = parseAttendanceExcel(buffer);
        return result;
      }),

    importConfirm: adminProcedure
      .input(z.object({
        courseId: z.number(),
        records: z.array(z.object({
          studentName: z.string(),
          studentDni: z.string().optional(),
          date: z.string(),
          status: z.enum(["presente", "ausente", "justificado", "tarde"]),
          notes: z.string().optional(),
        })),
      }))
      .mutation(async ({ input, ctx }) => {
        const course = await db.getCourseById(input.courseId);
        if (!course) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Curso no encontrado' });
        }

        const students = await db.getStudentsByCourse(input.courseId);
        const studentMap = new Map<string, number>();
        
        students.forEach(student => {
          studentMap.set(`${student.lastName},${student.firstName}`, student.id);
          if (student.dni) {
            studentMap.set(student.dni, student.id);
          }
        });

        let successCount = 0;
        let failureCount = 0;
        const errors: string[] = [];

        for (const record of input.records) {
          try {
            let studentId: number | undefined;
            
            if (record.studentDni) {
              studentId = studentMap.get(record.studentDni);
            }
            
            if (!studentId) {
              const nameKey = Array.from(studentMap.entries()).find(([key]) => 
                key.toLowerCase().includes(record.studentName.toLowerCase())
              )?.[1];
              studentId = nameKey;
            }

            if (!studentId) {
              failureCount++;
              errors.push(`No se encontro estudiante: ${record.studentName}`);
              continue;
            }

            const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
            const match = record.date.match(dateRegex);
            
            if (!match) {
              failureCount++;
              errors.push(`Fecha invalida para ${record.studentName}: ${record.date}`);
              continue;
            }

            const [, day, month, year] = match;
            const date = new Date(parseInt(year, 10), parseInt(month, 10) - 1, parseInt(day, 10));

            await db.createAttendance({
              studentId,
              courseId: input.courseId,
              date,
              status: record.status,
              notes: record.notes,
              recordedBy: ctx.user.id,
            });

            successCount++;

            if (record.status === 'ausente') {
              const student = await db.getStudentById(studentId);
              if (student) {
                await notifyOwner({
                  title: "Asistencias importadas - Inasistencia",
                  content: `${student.lastName}, ${student.firstName} - Ausente el ${date.toLocaleDateString('es-AR')}`
                });
              }
            }
          } catch (error) {
            failureCount++;
            errors.push(`Error al procesar ${record.studentName}: ${error instanceof Error ? error.message : 'Error desconocido'}`);
          }
        }

        await notifyOwner({
          title: "Importacion de asistencias completada",
          content: `Se importaron ${successCount} registros correctamente. ${failureCount} registros fallaron.`
        });

        return {
          successCount,
          failureCount,
          totalCount: input.records.length,
          errors,
        };
      }),
  }),

  // ============================================
  // ACADEMIC EVENTS ROUTER
  // ============================================
  academicEvents: router({
    list: protectedProcedure
      .input(z.object({
        startDate: z.date().optional(),
        endDate: z.date().optional(),
        courseId: z.number().optional(),
        eventType: z.string().optional(),
      }))
      .query(async ({ input }) => {
        return await db.listAcademicEvents(input);
      }),

    getById: protectedProcedure
      .input(z.number())
      .query(async ({ input }) => {
        return await db.getAcademicEventById(input);
      }),

    create: adminProcedure
      .input(z.object({
        title: z.string().min(1),
        description: z.string().optional(),
        eventType: z.enum(["feriado", "receso", "examen", "acto_escolar", "reunion_padres", "jornada_pedagogica", "otro"]),
        startDate: z.date(),
        endDate: z.date(),
        affectsAttendance: z.boolean().optional(),
        courseId: z.number().optional(),
        color: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (input.startDate > input.endDate) {
          throw new TRPCError({ code: 'BAD_REQUEST', message: 'La fecha de inicio debe ser anterior a la fecha de fin' });
        }

        const event = await db.createAcademicEvent({
          ...input,
          affectsAttendance: input.affectsAttendance ?? true,
          color: input.color ?? '#3b82f6',
          createdBy: ctx.user.id,
        });

        await notifyOwner({
          title: "Evento académico creado",
          content: `${input.title} - ${input.startDate.toLocaleDateString('es-AR')}`
        });

        return event;
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        eventType: z.enum(["feriado", "receso", "examen", "acto_escolar", "reunion_padres", "jornada_pedagogica", "otro"]).optional(),
        startDate: z.date().optional(),
        endDate: z.date().optional(),
        affectsAttendance: z.boolean().optional(),
        courseId: z.number().optional(),
        color: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;

        if (data.startDate && data.endDate && data.startDate > data.endDate) {
          throw new TRPCError({ code: 'BAD_REQUEST', message: 'La fecha de inicio debe ser anterior a la fecha de fin' });
        }

        await db.updateAcademicEvent(id, data);
        return await db.getAcademicEventById(id);
      }),

    delete: adminProcedure
      .input(z.number())
      .mutation(async ({ input }) => {
        const event = await db.getAcademicEventById(input);
        if (!event) {
          throw new TRPCError({ code: 'NOT_FOUND', message: 'Evento no encontrado' });
        }

        await db.deleteAcademicEvent(input);
        return { success: true };
      }),

    getByMonth: protectedProcedure
      .input(z.object({
        year: z.number(),
        month: z.number().min(1).max(12),
        courseId: z.number().optional(),
      }))
      .query(async ({ input }) => {
        return await db.getAcademicEventsByMonth(input.year, input.month, input.courseId);
      }),

    isEventDate: protectedProcedure
      .input(z.object({
        date: z.date(),
        courseId: z.number().optional(),
      }))
      .query(async ({ input }) => {
        return await db.isDateAcademicEvent(input.date, input.courseId);
      }),
  }),
});

export type AppRouter = typeof appRouter;
