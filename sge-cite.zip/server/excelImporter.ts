import * as XLSX from 'xlsx';
import * as db from './db';
import { InsertStudent, InsertSubject } from '../drizzle/schema';
import { parseWordFile, detectFileFormat } from './wordParser';
import { parsePdfFile } from './pdfParser';

export interface ImportResult {
  success: boolean;
  recordsImported: number;
  recordsFailed: number;
  errors: Array<{ row: number; error: string; data?: any }>;
}

export interface StudentImportRow {
  apellidoNombre?: string;
  firstName?: string;
  lastName?: string;
  dni?: string;
  year?: number;
  division?: string;
  shift?: "mañana" | "tarde" | "vespertino";
  studentPhone?: string;
  parentPhone?: string;
  address?: string;
  enrollmentBook?: string;
  enrollmentFolio?: string;
  intensifica?: string;
  recursa?: string;
  pendientes?: string;
}

/**
 * Procesa un archivo (Excel, Word o PDF) y retorna los datos parseados
 */
export async function parseMultiFormatFile(buffer: Buffer, fileName: string): Promise<StudentImportRow[]> {
  const format = detectFileFormat(fileName);
  
  if (format === 'word') {
    return parseWordFileAsStudents(buffer);
  } else if (format === 'pdf') {
    return parsePdfFileAsStudents(buffer);
  } else {
    return parseExcelFile(buffer);
  }
}

/**
 * Procesa un archivo Excel y retorna los datos parseados
 */
/**
 * Procesa datos de Word y los convierte a formato de estudiantes
 */
async function parseWordFileAsStudents(buffer: Buffer): Promise<StudentImportRow[]> {
  const parsed = await parseWordFile(buffer);
  return convertParsedDataToStudents(parsed.rows);
}

/**
 * Procesa datos de PDF y los convierte a formato de estudiantes
 */
async function parsePdfFileAsStudents(buffer: Buffer): Promise<StudentImportRow[]> {
  const parsed = await parsePdfFile(buffer);
  return convertParsedDataToStudents(parsed.rows);
}

/**
 * Convierte datos parseados genéricos a formato de estudiantes
 */
function convertParsedDataToStudents(rows: Record<string, string | number | boolean | null>[]): StudentImportRow[] {
  return rows.map((row) => {
    const result: StudentImportRow = {};
    
    // Mapear campos comunes
    Object.entries(row).forEach(([key, value]) => {
      const lowerKey = key.toLowerCase().trim();
      
      if (lowerKey.includes('apellido') || lowerKey.includes('nombre')) {
        result.apellidoNombre = String(value || '');
      } else if (lowerKey.includes('dni')) {
        result.dni = String(value || '');
      } else if (lowerKey.includes('teléfono') || lowerKey.includes('celular')) {
        result.studentPhone = String(value || '');
      } else if (lowerKey.includes('padre') || lowerKey.includes('tutor')) {
        result.parentPhone = String(value || '');
      } else if (lowerKey.includes('dirección') || lowerKey.includes('domicilio')) {
        result.address = String(value || '');
      } else if (lowerKey.includes('intensif')) {
        result.intensifica = String(value || '');
      } else if (lowerKey.includes('recursa')) {
        result.recursa = String(value || '');
      } else if (lowerKey.includes('pendiente')) {
        result.pendientes = String(value || '');
      } else if (lowerKey.includes('libro')) {
        result.enrollmentBook = String(value || '');
      } else if (lowerKey.includes('folio')) {
        result.enrollmentFolio = String(value || '');
      }
    });
    
    return result;
  });
}

export async function parseExcelFile(buffer: Buffer): Promise<StudentImportRow[]> {
  const workbook = XLSX.read(buffer, { type: 'buffer' });
  const results: StudentImportRow[] = [];
  
  // Procesar cada hoja del Excel
  for (const sheetName of workbook.SheetNames) {
    // Saltar hojas de separadores (TURNO MAÑANA, TURNO TARDE, etc.)
    if (sheetName.includes('TURNO') || sheetName === 'AFTE') {
      continue;
    }
    
    const worksheet = workbook.Sheets[sheetName];
    if (!worksheet) continue;
    
    const jsonData = XLSX.utils.sheet_to_json(worksheet, { defval: '' });
    
    // Determinar año y división del nombre de la hoja
    const sheetMatch = sheetName.match(/^(\d)([A-Z])$/);
    let year: number | undefined;
    let division: string | undefined;
    
    if (sheetMatch) {
      year = parseInt(sheetMatch[1]);
      division = sheetMatch[2];
    }
    
    // Determinar turno basado en el contexto
    let shift: "mañana" | "tarde" | "vespertino" | undefined;
    const sheetIndex = workbook.SheetNames.indexOf(sheetName);
    
    // Buscar hacia atrás para encontrar el último separador de turno
    for (let i = sheetIndex; i >= 0; i--) {
      const prevSheet = workbook.SheetNames[i];
      if (prevSheet?.includes('MAÑANA')) {
        shift = 'mañana';
        break;
      } else if (prevSheet?.includes('TARDE')) {
        shift = 'tarde';
        break;
      } else if (prevSheet?.includes('VESPERTINO')) {
        shift = 'vespertino';
        break;
      }
    }
    
    // Procesar cada fila
    for (const row of jsonData as any[]) {
      // Buscar el campo de nombre (puede tener diferentes nombres de columna)
      const apellidoNombre = 
        row['APELLIDO Y NOMBRE'] || 
        row['apellidoNombre'] || 
        row['Apellido y Nombre'] ||
        row['nombre'] ||
        '';
      
      if (!apellidoNombre || typeof apellidoNombre !== 'string') continue;
      
      // Extraer materias
      const intensifica = row['INTENSIFICA 1'] || row['INTENSIFICA 2'] || row['intensifica'] || '';
      const recursa = row['RECURSA 1'] || row['RECURSA 2'] || row['recursa'] || '';
      const pendientes = row['PENDIENTES'] || row['pendientes'] || '';
      
      const libro = row['LIBRO'] || row['libro'] || '';
      const folio = row['FOLIO'] || row['folio'] || '';
      
      results.push({
        apellidoNombre: apellidoNombre.trim(),
        year,
        division,
        shift,
        intensifica: intensifica.toString().trim(),
        recursa: recursa.toString().trim(),
        pendientes: pendientes.toString().trim(),
        enrollmentBook: libro.toString().trim(),
        enrollmentFolio: folio.toString().trim(),
      });
    }
  }
  
  return results;
}

/**
 * Separa apellido y nombre de un string completo
 */
function splitName(fullName: string): { firstName: string; lastName: string } {
  const parts = fullName.trim().split(/\s+/);
  
  if (parts.length === 1) {
    return { firstName: parts[0] || '', lastName: '' };
  }
  
  // Asumir que la primera parte es el apellido y el resto es el nombre
  const lastName = parts[0] || '';
  const firstName = parts.slice(1).join(' ');
  
  return { firstName, lastName };
}

/**
 * Parsea materias de un string separado por espacios o comas
 */
function parseSubjects(subjectsStr: string): string[] {
  if (!subjectsStr) return [];
  
  // Separar por comas o múltiples espacios
  const subjects = subjectsStr
    .split(/[,\n]+/)
    .map(s => s.trim())
    .filter(s => s.length > 0);
  
  return subjects;
}

/**
 * Calcula el porcentaje de aprobación basado en las materias
 */
function calculateApprovalPercentage(
  pendientes: string[],
  recursadas: string[],
  intensificadas: string[]
): number {
  // Asumir que un estudiante tiene aproximadamente 10 materias por año
  const totalSubjects = 10;
  const failedSubjects = pendientes.length + recursadas.length + intensificadas.length;
  
  if (failedSubjects === 0) return 100;
  
  const approvedSubjects = Math.max(0, totalSubjects - failedSubjects);
  return Math.round((approvedSubjects / totalSubjects) * 100);
}

/**
 * Importa estudiantes desde datos parseados del Excel
 */
export async function importStudents(
  rows: StudentImportRow[],
  userId: number
): Promise<ImportResult> {
  const result: ImportResult = {
    success: true,
    recordsImported: 0,
    recordsFailed: 0,
    errors: [],
  };
  
  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    
    try {
      // Validar datos requeridos
      if (!row.apellidoNombre) {
        result.errors.push({
          row: i + 1,
          error: 'Nombre y apellido son requeridos',
          data: row,
        });
        result.recordsFailed++;
        continue;
      }
      
      if (!row.year || !row.division || !row.shift) {
        result.errors.push({
          row: i + 1,
          error: 'Año, división y turno son requeridos',
          data: row,
        });
        result.recordsFailed++;
        continue;
      }
      
      // Separar nombre y apellido
      const { firstName, lastName } = splitName(row.apellidoNombre);
      
      // Generar DNI temporal si no existe (se puede actualizar después)
      const dni = row.dni || `TEMP-${Date.now()}-${i}`;
      
      // Parsear materias
      const pendientes = parseSubjects(row.pendientes || '');
      const recursadas = parseSubjects(row.recursa || '');
      const intensificadas = parseSubjects(row.intensifica || '');
      
      // Calcular porcentaje de aprobación
      const approvalPercentage = calculateApprovalPercentage(
        pendientes,
        recursadas,
        intensificadas
      );
      
      // Verificar si el estudiante ya existe
      let existingStudent = row.dni ? await db.getStudentByDni(row.dni) : undefined;
      
      let studentId: number;
      
      if (existingStudent) {
        // Actualizar estudiante existente
        await db.updateStudent(existingStudent.id, {
          firstName,
          lastName,
          year: row.year,
          division: row.division,
          shift: row.shift,
          studentPhone: row.studentPhone,
          parentPhone: row.parentPhone,
          address: row.address,
          enrollmentBook: row.enrollmentBook,
          enrollmentFolio: row.enrollmentFolio,
          approvalPercentage,
          updatedBy: userId,
        });
        studentId = existingStudent.id;
        
        // Eliminar materias existentes para reemplazarlas
        await db.deleteSubjectsByStudent(studentId);
      } else {
        // Crear nuevo estudiante
        const insertResult = await db.createStudent({
          firstName,
          lastName,
          dni,
          year: row.year,
          division: row.division,
          shift: row.shift,
          studentPhone: row.studentPhone,
          parentPhone: row.parentPhone,
          address: row.address,
          enrollmentBook: row.enrollmentBook,
          enrollmentFolio: row.enrollmentFolio,
          approvalPercentage,
          createdBy: userId,
          updatedBy: userId,
        });
        
        // Obtener el ID del estudiante recién creado
        studentId = Number(insertResult[0].insertId);
      }
      
      // Agregar materias pendientes
      for (const subject of pendientes) {
        await db.createSubject({
          studentId,
          subjectName: subject,
          year: row.year,
          status: 'pendiente',
        });
      }
      
      // Agregar materias recursadas
      for (const subject of recursadas) {
        await db.createSubject({
          studentId,
          subjectName: subject,
          year: row.year,
          status: 'recursada',
        });
      }
      
      // Agregar materias intensificadas
      for (const subject of intensificadas) {
        await db.createSubject({
          studentId,
          subjectName: subject,
          year: row.year,
          status: 'intensificada',
        });
      }
      
      result.recordsImported++;
    } catch (error: any) {
      result.errors.push({
        row: i + 1,
        error: error.message || 'Error desconocido',
        data: row,
      });
      result.recordsFailed++;
    }
  }
  
  result.success = result.recordsFailed === 0;
  
  return result;
}
