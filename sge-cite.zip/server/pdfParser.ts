/**
 * Parsea un archivo PDF y extrae tablas o texto estructurado
 */
export async function parsePdfFile(buffer: Buffer): Promise<{
  format: "pdf";
  headers: string[];
  rows: Record<string, string | number | boolean | null>[];
  rawText?: string;
}> {
  try {
    // Import dinámico de pdf-parse
    const pdfParseModule = await import("pdf-parse");
    const pdfParse = (pdfParseModule as any).default || pdfParseModule;
    const data = await pdfParse(buffer);

    // Extraer texto de todas las páginas
    const fullText = data.text || "";

    if (!fullText.trim()) {
      throw new Error("No se pudo extraer texto del PDF");
    }

    // Intentar parsear como tabla
    const parsedRows = parseTextToRows(fullText);

    return {
      format: "pdf",
      headers: parsedRows.length > 0 ? Object.keys(parsedRows[0]) : [],
      rows: parsedRows,
      rawText: fullText,
    };
  } catch (error) {
    throw new Error(
      `Error al parsear archivo PDF: ${error instanceof Error ? error.message : "Error desconocido"}`
    );
  }
}

/**
 * Parsea texto plano a filas estructuradas
 */
function parseTextToRows(
  text: string
): Record<string, string | number | boolean | null>[] {
  const lines = text.split("\n").filter((line) => line.trim());

  if (lines.length === 0) {
    return [];
  }

  // Intentar detectar si la primera línea son headers
  const commonHeaders = [
    "nombre",
    "apellido",
    "dni",
    "email",
    "teléfono",
    "fecha",
    "estado",
    "curso",
    "año",
    "division",
    "turno",
    "materia",
    "presente",
    "ausente",
    "justificado",
  ];

  const firstLineWords = lines[0].toLowerCase().split(/[\s,;|]+/);
  const isFirstLineHeaders = firstLineWords.some((word) =>
    commonHeaders.some((header) => word.includes(header))
  );

  let headers: string[];
  let dataLines: string[];

  if (isFirstLineHeaders) {
    // Usar la primera línea como headers
    headers = lines[0]
      .split(/[\t,;|]+/)
      .map((h) => h.trim())
      .filter((h) => h);
    dataLines = lines.slice(1);
  } else {
    // Intentar detectar separadores
    const possibleSeparators = ["\t", "|", ",", ";"];
    let bestSeparator = ",";
    let maxColumns = 0;

    for (const sep of possibleSeparators) {
      const columnCount = Math.max(
        ...lines.map((line) => line.split(sep).length)
      );
      if (columnCount > maxColumns) {
        maxColumns = columnCount;
        bestSeparator = sep;
      }
    }

    // Generar headers genéricos
    headers = Array.from({ length: maxColumns }, (_, i) => `Columna ${i + 1}`);
    dataLines = lines;
  }

  const rows: Record<string, string | number | boolean | null>[] = [];

  dataLines.forEach((line) => {
    if (!line.trim()) return;

    const values = line
      .split(/[\t,;|]+/)
      .map((v) => v.trim())
      .filter((v) => v);
    const row: Record<string, string | number | boolean | null> = {};

    headers.forEach((header, index) => {
      const value = values[index] || "";
      row[header] = value;
    });

    // Solo agregar si tiene al menos una columna con datos
    if (Object.values(row).some((v) => v)) {
      rows.push(row);
    }
  });

  return rows;
}
