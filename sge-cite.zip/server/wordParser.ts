import { Readable } from "stream";

/**
 * Interfaz para datos parseados de cualquier formato
 */
export interface ParsedData {
  headers: string[];
  rows: Record<string, string | number | boolean | null>[];
  format: "excel" | "word" | "pdf";
  rawText?: string;
}

/**
 * Parsea un archivo Word (.docx) y extrae tablas o texto estructurado
 */
export async function parseWordFile(buffer: Buffer): Promise<ParsedData> {
  try {
    // Usamos una aproximación simple: extraer texto del docx
    // Los archivos .docx son archivos ZIP con XML dentro
    const JSZip = (await import("jszip")).default;
    const zip = new JSZip();
    await zip.loadAsync(buffer);

    // Leer el documento principal
    const docXml = await zip.file("word/document.xml")?.async("text");
    if (!docXml) {
      throw new Error("No se encontró document.xml en el archivo Word");
    }

    // Parsear XML y extraer tablas
    const tables = extractTablesFromWordXml(docXml);

    if (tables.length > 0) {
      // Si hay tablas, usar la primera
      return {
        format: "word",
        headers: tables[0].headers,
        rows: tables[0].rows,
      };
    }

    // Si no hay tablas, extraer texto plano
    const text = extractTextFromWordXml(docXml);
    const parsedRows = parseTextToRows(text);

    return {
      format: "word",
      headers: parsedRows.length > 0 ? Object.keys(parsedRows[0]) : [],
      rows: parsedRows,
      rawText: text,
    };
  } catch (error) {
    throw new Error(
      `Error al parsear archivo Word: ${error instanceof Error ? error.message : "Error desconocido"}`
    );
  }
}

/**
 * Extrae tablas del XML de un documento Word
 */
function extractTablesFromWordXml(
  xmlContent: string
): Array<{ headers: string[]; rows: Record<string, string | number | boolean | null>[] }> {
  const tables: Array<{ headers: string[]; rows: Record<string, string | number | boolean | null>[] }> = [];

  // Regex para encontrar tablas (tbl)
  const tableRegex = /<w:tbl>[\s\S]*?<\/w:tbl>/g;
  const tableMatches = xmlContent.match(tableRegex) || [];

  tableMatches.forEach((tableXml) => {
    try {
      const rows = extractRowsFromTableXml(tableXml);
      if (rows.length > 0) {
        // Primera fila como headers
        const headers = rows[0];
        const dataRows = rows.slice(1).map((row) => {
          const obj: Record<string, string | number | boolean | null> = {};
          headers.forEach((header, index) => {
            obj[header] = row[index] || "";
          });
          return obj;
        });

        tables.push({
          headers,
          rows: dataRows,
        });
      }
    } catch (error) {
      console.error("Error al extraer tabla:", error);
    }
  });

  return tables;
}

/**
 * Extrae filas de una tabla XML
 */
function extractRowsFromTableXml(tableXml: string): string[][] {
  const rows: string[][] = [];

  // Regex para encontrar filas (tr)
  const rowRegex = /<w:tr>[\s\S]*?<\/w:tr>/g;
  const rowMatches = tableXml.match(rowRegex) || [];

  rowMatches.forEach((rowXml) => {
    try {
      const cells = extractCellsFromRowXml(rowXml);
      if (cells.length > 0) {
        rows.push(cells);
      }
    } catch (error) {
      console.error("Error al extraer fila:", error);
    }
  });

  return rows;
}

/**
 * Extrae celdas de una fila XML
 */
function extractCellsFromRowXml(rowXml: string): string[] {
  const cells: string[] = [];

  // Regex para encontrar celdas (tc)
  const cellRegex = /<w:tc>[\s\S]*?<\/w:tc>/g;
  const cellMatches = rowXml.match(cellRegex) || [];

  cellMatches.forEach((cellXml) => {
    try {
      // Extraer texto de la celda
      const textRegex = /<w:t>([\s\S]*?)<\/w:t>/g;
      const textMatches = cellXml.match(textRegex) || [];

      const cellText = textMatches
        .map((match) => {
          const text = match.replace(/<w:t>([\s\S]*?)<\/w:t>/, "$1");
          return text;
        })
        .join(" ")
        .trim();

      cells.push(cellText);
    } catch (error) {
      console.error("Error al extraer celda:", error);
      cells.push("");
    }
  });

  return cells;
}

/**
 * Extrae texto plano del XML de un documento Word
 */
function extractTextFromWordXml(xmlContent: string): string {
  // Regex para encontrar elementos de texto (t)
  const textRegex = /<w:t>([\s\S]*?)<\/w:t>/g;
  const matches = xmlContent.match(textRegex) || [];

  const text = matches
    .map((match) => {
      return match.replace(/<w:t>([\s\S]*?)<\/w:t>/, "$1");
    })
    .join("\n");

  return text;
}

/**
 * Parsea texto plano a filas estructuradas
 */
function parseTextToRows(
  text: string
): Record<string, string | number | boolean | null>[] {
  const lines = text.split("\n").filter((line) => line.trim());

  if (lines.length === 0) {
    return [];
  }

  // Intentar detectar si la primera línea son headers
  // (si contiene palabras comunes como "nombre", "apellido", etc.)
  const commonHeaders = [
    "nombre",
    "apellido",
    "dni",
    "email",
    "teléfono",
    "fecha",
    "estado",
    "curso",
    "año",
    "division",
  ];
  const firstLineWords = lines[0].toLowerCase().split(/[\s,;]+/);
  const isFirstLineHeaders = firstLineWords.some((word) =>
    commonHeaders.some((header) => word.includes(header))
  );

  let headers: string[];
  let dataLines: string[];

  if (isFirstLineHeaders) {
    headers = lines[0].split(/[\t,;]+/).map((h) => h.trim());
    dataLines = lines.slice(1);
  } else {
    // Generar headers genéricos
    const maxColumns = Math.max(
      ...lines.map((line) => line.split(/[\t,;]+/).length)
    );
    headers = Array.from({ length: maxColumns }, (_, i) => `Columna ${i + 1}`);
    dataLines = lines;
  }

  const rows: Record<string, string | number | boolean | null>[] = [];

  dataLines.forEach((line) => {
    const values = line.split(/[\t,;]+/).map((v) => v.trim());
    const row: Record<string, string | number | boolean | null> = {};

    headers.forEach((header, index) => {
      const value = values[index] || "";
      row[header] = value;
    });

    rows.push(row);
  });

  return rows;
}

/**
 * Detecta el formato de archivo basado en la extensión
 */
export function detectFileFormat(filename: string): "excel" | "word" | "pdf" | null {
  const ext = filename.toLowerCase().split(".").pop();

  switch (ext) {
    case "xlsx":
    case "xls":
      return "excel";
    case "docx":
    case "doc":
      return "word";
    case "pdf":
      return "pdf";
    default:
      return null;
  }
}
