import { describe, expect, it } from "vitest";
import { parseAttendanceExcel } from "./attendanceImporter";
import * as XLSX from 'xlsx';

describe("attendanceImporter", () => {
  it("should parse valid attendance records from Excel", () => {
    // Crear un archivo Excel de prueba
    const data = [
      ["Nombre", "DNI", "Fecha", "Estado", "Notas"],
      ["Juan García", "12345678", "15/01/2024", "presente", ""],
      ["María López", "87654321", "15/01/2024", "ausente", "Enfermo"],
      ["Carlos Pérez", "11111111", "15/01/2024", "justificado", "Certificado médico"],
    ];

    const worksheet = XLSX.utils.aoa_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Asistencias");
    const buffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'buffer' });

    const result = parseAttendanceExcel(buffer as Buffer);

    expect(result.success).toBe(true);
    expect(result.totalRecords).toBe(3);
    expect(result.validRecords).toBe(3);
    expect(result.invalidRecords).toBe(0);
    expect(result.records).toHaveLength(3);
  });

  it("should detect invalid dates", () => {
    const data = [
      ["Nombre", "DNI", "Fecha", "Estado", "Notas"],
      ["Juan García", "12345678", "32/01/2024", "presente", ""],
      ["María López", "87654321", "15/13/2024", "ausente", ""],
    ];

    const worksheet = XLSX.utils.aoa_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Asistencias");
    const buffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'buffer' });

    const result = parseAttendanceExcel(buffer as Buffer);

    expect(result.success).toBe(false);
    expect(result.invalidRecords).toBe(2);
    expect(result.records.some(r => r.errors && r.errors.length > 0)).toBe(true);
  });

  it("should detect invalid status values", () => {
    const data = [
      ["Nombre", "DNI", "Fecha", "Estado", "Notas"],
      ["Juan García", "12345678", "15/01/2024", "invalido", ""],
    ];

    const worksheet = XLSX.utils.aoa_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Asistencias");
    const buffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'buffer' });

    const result = parseAttendanceExcel(buffer as Buffer);

    expect(result.success).toBe(false);
    expect(result.invalidRecords).toBe(1);
    expect(result.records[0]?.errors).toBeDefined();
  });

  it("should handle missing required fields", () => {
    const data = [
      ["Nombre", "DNI", "Fecha", "Estado", "Notas"],
      ["", "12345678", "15/01/2024", "presente", ""],
      ["María López", "", "", "ausente", ""],
    ];

    const worksheet = XLSX.utils.aoa_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Asistencias");
    const buffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'buffer' });

    const result = parseAttendanceExcel(buffer as Buffer);

    expect(result.success).toBe(false);
    expect(result.invalidRecords).toBeGreaterThan(0);
  });

  it("should reject future dates", () => {
    const futureDate = new Date();
    futureDate.setDate(futureDate.getDate() + 1);
    const futureDateStr = `${futureDate.getDate()}/${futureDate.getMonth() + 1}/${futureDate.getFullYear()}`;

    const data = [
      ["Nombre", "DNI", "Fecha", "Estado", "Notas"],
      ["Juan García", "12345678", futureDateStr, "presente", ""],
    ];

    const worksheet = XLSX.utils.aoa_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Asistencias");
    const buffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'buffer' });

    const result = parseAttendanceExcel(buffer as Buffer);

    expect(result.success).toBe(false);
    expect(result.invalidRecords).toBe(1);
  });

  it("should handle empty files", () => {
    const data: string[][] = [];
    const worksheet = XLSX.utils.aoa_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Asistencias");
    const buffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'buffer' });

    const result = parseAttendanceExcel(buffer as Buffer);

    expect(result.success).toBe(false);
    expect(result.errors.length).toBeGreaterThan(0);
  });

  it("should accept all valid status values", () => {
    const data = [
      ["Nombre", "DNI", "Fecha", "Estado", "Notas"],
      ["Juan García", "12345678", "15/01/2024", "presente", ""],
      ["María López", "87654321", "15/01/2024", "ausente", ""],
      ["Carlos Pérez", "11111111", "15/01/2024", "justificado", ""],
      ["Ana Martínez", "22222222", "15/01/2024", "tarde", ""],
    ];

    const worksheet = XLSX.utils.aoa_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Asistencias");
    const buffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'buffer' });

    const result = parseAttendanceExcel(buffer as Buffer);

    expect(result.success).toBe(true);
    expect(result.validRecords).toBe(4);
  });
});
