import { describe, expect, it, beforeAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAdminContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-admin",
    email: "admin@test.com",
    name: "Test Admin",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return ctx;
}

function createUserContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 2,
    openId: "test-user",
    email: "user@test.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return ctx;
}

describe("students router", () => {
  it("should list students with filters", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.students.list({
      sortBy: "name",
      sortOrder: "asc",
    });

    expect(result).toHaveProperty("students");
    expect(result).toHaveProperty("total");
    expect(Array.isArray(result.students)).toBe(true);
    expect(typeof result.total).toBe("number");
  });

  it("should get dashboard statistics", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const stats = await caller.statistics.dashboard();

    expect(stats).toHaveProperty("totalStudents");
    expect(stats).toHaveProperty("averageApproval");
    expect(stats).toHaveProperty("byShift");
    expect(stats).toHaveProperty("byYear");
    expect(typeof stats.totalStudents).toBe("number");
    expect(typeof stats.averageApproval).toBe("number");
  });

  it("should allow user role to list students", async () => {
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.students.list({});

    expect(result).toHaveProperty("students");
    expect(Array.isArray(result.students)).toBe(true);
  });

  it("should list courses", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const courses = await caller.courses.list();

    expect(Array.isArray(courses)).toBe(true);
  });
});

describe("authorization", () => {
  it("should prevent non-admin from deleting students", async () => {
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.students.delete({ id: 999 })
    ).rejects.toThrow();
  });

  it("should allow admin to access admin-only endpoints", async () => {
    const ctx = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    // This should not throw
    const courses = await caller.courses.list();
    expect(Array.isArray(courses)).toBe(true);
  });
});
