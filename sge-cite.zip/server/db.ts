import { eq, and, or, like, desc, asc, sql, count, gte, lte, isNull } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users, 
  students, 
  InsertStudent, 
  Student,
  subjects,
  InsertSubject,
  Subject,
  authorizedPersons,
  InsertAuthorizedPerson,
  AuthorizedPerson,
  documents,
  InsertDocument,
  Document,
  courses,
  InsertCourse,
  Course,
  importHistory,
  InsertImportHistory,
  ImportHistory,
  attendances,
  InsertAttendance,
  Attendance,
  attendanceSummary,
  InsertAttendanceSummary,
  AttendanceSummary,
  academicEvents,
  InsertAcademicEvent,
  AcademicEvent
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============================================
// USER HELPERS
// ============================================

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ============================================
// STUDENT HELPERS
// ============================================

export async function createStudent(student: InsertStudent) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(students).values(student);
  return result;
}

export async function updateStudent(id: number, data: Partial<InsertStudent>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(students).set(data).where(eq(students.id, id));
}

export async function deleteStudent(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(students).where(eq(students.id, id));
}

export async function getStudentById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.select().from(students).where(eq(students.id, id)).limit(1);
  return result[0];
}

export async function getStudentByDni(dni: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.select().from(students).where(eq(students.dni, dni)).limit(1);
  return result[0];
}

export interface StudentFilters {
  year?: number;
  division?: string;
  shift?: "mañana" | "tarde" | "vespertino";
  search?: string; // Busca en nombre, apellido o DNI
  hasPendingSubjects?: boolean;
  hasRecursadas?: boolean;
  hasIntensificadas?: boolean;
  sortBy?: "name" | "year" | "approvalPercentage";
  sortOrder?: "asc" | "desc";
  limit?: number;
  offset?: number;
}

export async function listStudents(filters: StudentFilters = {}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  let query = db.select().from(students);
  
  const conditions = [];
  
  if (filters.year !== undefined) {
    conditions.push(eq(students.year, filters.year));
  }
  
  if (filters.division) {
    conditions.push(eq(students.division, filters.division));
  }
  
  if (filters.shift) {
    conditions.push(eq(students.shift, filters.shift));
  }
  
  if (filters.search) {
    const searchTerm = `%${filters.search}%`;
    conditions.push(
      or(
        like(students.firstName, searchTerm),
        like(students.lastName, searchTerm),
        like(students.dni, searchTerm)
      )!
    );
  }
  
  if (conditions.length > 0) {
    query = query.where(and(...conditions)!) as any;
  }
  
  // Ordenamiento
  const sortBy = filters.sortBy || "name";
  const sortOrder = filters.sortOrder || "asc";
  
  if (sortBy === "name") {
    query = query.orderBy(
      sortOrder === "asc" ? asc(students.lastName) : desc(students.lastName)
    ) as any;
  } else if (sortBy === "year") {
    query = query.orderBy(
      sortOrder === "asc" ? asc(students.year) : desc(students.year)
    ) as any;
  } else if (sortBy === "approvalPercentage") {
    query = query.orderBy(
      sortOrder === "asc" ? asc(students.approvalPercentage) : desc(students.approvalPercentage)
    ) as any;
  }
  
  // Paginación
  if (filters.limit) {
    query = query.limit(filters.limit) as any;
  }
  
  if (filters.offset) {
    query = query.offset(filters.offset) as any;
  }
  
  const results = await query;
  
  // Filtros adicionales que requieren joins con subjects
  if (filters.hasPendingSubjects || filters.hasRecursadas || filters.hasIntensificadas) {
    const filteredResults = [];
    
    for (const student of results) {
      const studentSubjects = await getSubjectsByStudent(student.id);
      
      if (filters.hasPendingSubjects && studentSubjects.some(s => s.status === "pendiente")) {
        filteredResults.push(student);
      } else if (filters.hasRecursadas && studentSubjects.some(s => s.status === "recursada")) {
        filteredResults.push(student);
      } else if (filters.hasIntensificadas && studentSubjects.some(s => s.status === "intensificada")) {
        filteredResults.push(student);
      } else if (!filters.hasPendingSubjects && !filters.hasRecursadas && !filters.hasIntensificadas) {
        filteredResults.push(student);
      }
    }
    
    return filteredResults;
  }
  
  return results;
}

export async function countStudents(filters: StudentFilters = {}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const conditions = [];
  
  if (filters.year !== undefined) {
    conditions.push(eq(students.year, filters.year));
  }
  
  if (filters.division) {
    conditions.push(eq(students.division, filters.division));
  }
  
  if (filters.shift) {
    conditions.push(eq(students.shift, filters.shift));
  }
  
  if (filters.search) {
    const searchTerm = `%${filters.search}%`;
    conditions.push(
      or(
        like(students.firstName, searchTerm),
        like(students.lastName, searchTerm),
        like(students.dni, searchTerm)
      )!
    );
  }
  
  let query = db.select({ count: count() }).from(students);
  
  if (conditions.length > 0) {
    query = query.where(and(...conditions)!) as any;
  }
  
  const result = await query;
  return result[0]?.count || 0;
}

// ============================================
// SUBJECT HELPERS
// ============================================

export async function createSubject(subject: InsertSubject) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(subjects).values(subject);
}

export async function updateSubject(id: number, data: Partial<InsertSubject>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(subjects).set(data).where(eq(subjects.id, id));
}

export async function deleteSubject(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(subjects).where(eq(subjects.id, id));
}

export async function getSubjectsByStudent(studentId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.select().from(subjects).where(eq(subjects.studentId, studentId));
}

export async function deleteSubjectsByStudent(studentId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(subjects).where(eq(subjects.studentId, studentId));
}

// ============================================
// AUTHORIZED PERSON HELPERS
// ============================================

export async function createAuthorizedPerson(person: InsertAuthorizedPerson) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(authorizedPersons).values(person);
}

export async function updateAuthorizedPerson(id: number, data: Partial<InsertAuthorizedPerson>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(authorizedPersons).set(data).where(eq(authorizedPersons.id, id));
}

export async function deleteAuthorizedPerson(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(authorizedPersons).where(eq(authorizedPersons.id, id));
}

export async function getAuthorizedPersonsByStudent(studentId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.select().from(authorizedPersons).where(eq(authorizedPersons.studentId, studentId));
}

// ============================================
// DOCUMENT HELPERS
// ============================================

export async function createDocument(document: InsertDocument) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(documents).values(document);
}

export async function deleteDocument(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.delete(documents).where(eq(documents.id, id));
}

export async function getDocumentsByStudent(studentId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.select().from(documents).where(eq(documents.studentId, studentId));
}

export async function getDocumentById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.select().from(documents).where(eq(documents.id, id)).limit(1);
  return result[0];
}

// ============================================
// COURSE HELPERS
// ============================================

export async function createCourse(course: InsertCourse) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.insert(courses).values(course);
}

export async function updateCourse(id: number, data: Partial<InsertCourse>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(courses).set(data).where(eq(courses.id, id));
}

export async function listCourses() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.select().from(courses);
}

export async function getCoursesByPreceptor(preceptorId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.select().from(courses).where(eq(courses.preceptorId, preceptorId));
}

// ============================================
// IMPORT HISTORY HELPERS
// ============================================

export async function createImportHistory(importData: InsertImportHistory) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(importHistory).values(importData);
  return result;
}

export async function updateImportHistory(id: number, data: Partial<InsertImportHistory>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(importHistory).set(data).where(eq(importHistory.id, id));
}

export async function getImportHistoryList(limit: number = 50) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.select().from(importHistory).orderBy(desc(importHistory.createdAt)).limit(limit);
}

// ============================================
// STATISTICS HELPERS
// ============================================

export async function getStudentStatistics() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Total de estudiantes
  const totalResult = await db.select({ count: count() }).from(students);
  const totalStudents = totalResult[0]?.count || 0;
  
  // Promedio de aprobación
  const avgResult = await db.select({ 
    avg: sql<number>`AVG(${students.approvalPercentage})` 
  }).from(students);
  const averageApproval = Math.round(avgResult[0]?.avg || 0);
  
  // Estudiantes por turno
  const byShiftResult = await db
    .select({ 
      shift: students.shift, 
      count: count() 
    })
    .from(students)
    .groupBy(students.shift);
  
  const byShift = byShiftResult.reduce((acc, row) => {
    acc[row.shift] = row.count;
    return acc;
  }, {} as Record<string, number>);
  
  // Estudiantes por año
  const byYearResult = await db
    .select({ 
      year: students.year, 
      count: count() 
    })
    .from(students)
    .groupBy(students.year);
  
  const byYear = byYearResult.reduce((acc, row) => {
    acc[row.year] = row.count;
    return acc;
  }, {} as Record<number, number>);
  
  return {
    totalStudents,
    averageApproval,
    byShift,
    byYear
  };
}

export async function getStudentsWithPendingSubjects() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Obtener todos los estudiantes con materias pendientes
  const pendingSubjects = await db
    .select({ studentId: subjects.studentId })
    .from(subjects)
    .where(eq(subjects.status, "pendiente"));
  
  const studentIds = Array.from(new Set(pendingSubjects.map(s => s.studentId)));
  
  if (studentIds.length === 0) return [];
  
  return await db
    .select()
    .from(students)
    .where(sql`${students.id} IN ${studentIds}`);
}

export async function getStudentsAtRisk(threshold: number = 50) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db
    .select()
    .from(students)
    .where(sql`${students.approvalPercentage} < ${threshold}`);
}


// ============================================
// ATTENDANCE HELPERS
// ============================================

export async function createAttendance(data: InsertAttendance) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(attendances).values(data);
}

export async function getAttendancesByStudent(studentId: number, startDate?: Date, endDate?: Date) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  let conditions = eq(attendances.studentId, studentId);
  
  if (startDate && endDate) {
    conditions = and(
      eq(attendances.studentId, studentId),
      sql`${attendances.date} >= ${startDate}`,
      sql`${attendances.date} <= ${endDate}`
    ) as any;
  }
  
  return await db.select().from(attendances).where(conditions).orderBy(desc(attendances.date));
}

export async function getAttendancesByCourse(courseId: number, startDate?: Date, endDate?: Date) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  let conditions = eq(attendances.courseId, courseId);
  
  if (startDate && endDate) {
    conditions = and(
      eq(attendances.courseId, courseId),
      sql`${attendances.date} >= ${startDate}`,
      sql`${attendances.date} <= ${endDate}`
    ) as any;
  }
  
  return await db.select().from(attendances).where(conditions).orderBy(desc(attendances.date));
}

export async function getAttendanceSummary(studentId: number, courseId: number, month: number, year: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.select()
    .from(attendanceSummary)
    .where(
      and(
        eq(attendanceSummary.studentId, studentId),
        eq(attendanceSummary.courseId, courseId),
        eq(attendanceSummary.month, month),
        eq(attendanceSummary.year, year)
      )
    )
    .limit(1);
  
  return result[0];
}

export async function updateAttendanceSummary(studentId: number, courseId: number, month: number, year: number, data: Partial<InsertAttendanceSummary>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const existing = await getAttendanceSummary(studentId, courseId, month, year);
  
  if (existing) {
    await db.update(attendanceSummary)
      .set(data)
      .where(
        and(
          eq(attendanceSummary.studentId, studentId),
          eq(attendanceSummary.courseId, courseId),
          eq(attendanceSummary.month, month),
          eq(attendanceSummary.year, year)
        )
      );
  } else {
    await db.insert(attendanceSummary).values({
      studentId,
      courseId,
      month,
      year,
      ...data,
    });
  }
}

export async function getStudentAbsenceReport(studentId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const studentData = await db.select().from(students).where(eq(students.id, studentId)).limit(1);
  if (!studentData.length) return null;
  
  const summaries = await db.select().from(attendanceSummary).where(eq(attendanceSummary.studentId, studentId));
  
  return {
    student: studentData[0],
    monthlySummaries: summaries,
    totalAbsences: summaries.reduce((sum, s) => sum + (s.absentDays || 0), 0),
    totalJustified: summaries.reduce((sum, s) => sum + (s.justifiedDays || 0), 0),
  };
}

export async function getCourseAbsenceReport(courseId: number, month?: number, year?: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  let conditions = eq(attendanceSummary.courseId, courseId);
  
  if (month !== undefined && year !== undefined) {
    conditions = and(
      eq(attendanceSummary.courseId, courseId),
      eq(attendanceSummary.month, month),
      eq(attendanceSummary.year, year)
    ) as any;
  }
  
  return await db.select().from(attendanceSummary).where(conditions);
}


// ============================================
// HELPER FUNCTIONS FOR ATTENDANCE IMPORT
// ============================================

export async function getCourseById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.select().from(courses).where(eq(courses.id, id)).limit(1);
  return result[0] || null;
}

export async function getStudentsByCourse(courseId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const course = await getCourseById(courseId);
  if (!course) return [];
  
  // Obtener estudiantes que coincidan con año, división y turno del curso
  const result = await db
    .select()
    .from(students)
    .where(
      and(
        eq(students.year, course.year),
        eq(students.division, course.division),
        eq(students.shift, course.shift)
      )!
    );
  
  return result;
}


// ============================================
// ACADEMIC EVENTS HELPERS
// ============================================

export async function createAcademicEvent(event: InsertAcademicEvent) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(academicEvents).values(event);
  return result;
}

export async function updateAcademicEvent(id: number, data: Partial<InsertAcademicEvent>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.update(academicEvents).set(data).where(eq(academicEvents.id, id));
  return result;
}

export async function deleteAcademicEvent(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.delete(academicEvents).where(eq(academicEvents.id, id));
  return result;
}

export async function getAcademicEventById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.select().from(academicEvents).where(eq(academicEvents.id, id)).limit(1);
  return result[0] || null;
}

export async function listAcademicEvents(filters?: {
  startDate?: Date;
  endDate?: Date;
  courseId?: number;
  eventType?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  let query = db.select().from(academicEvents);
  const conditions = [];
  
  if (filters?.startDate) {
    conditions.push(gte(academicEvents.startDate, filters.startDate));
  }
  
  if (filters?.endDate) {
    conditions.push(lte(academicEvents.endDate, filters.endDate));
  }
  
  if (filters?.courseId !== undefined) {
    conditions.push(
      or(
        eq(academicEvents.courseId, filters.courseId),
        isNull(academicEvents.courseId)
      )!
    );
  }
  
  if (filters?.eventType) {
    conditions.push(eq(academicEvents.eventType, filters.eventType as any));
  }
  
  if (conditions.length > 0) {
    query = query.where(and(...conditions)!) as any;
  }
  
  return await query.orderBy(asc(academicEvents.startDate));
}

export async function getEventsBetweenDates(startDate: Date, endDate: Date, courseId?: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const conditions = [
    and(
      gte(academicEvents.startDate, startDate),
      lte(academicEvents.endDate, endDate)
    )!
  ];
  
  if (courseId !== undefined) {
    conditions.push(
      or(
        eq(academicEvents.courseId, courseId),
        isNull(academicEvents.courseId)
      )!
    );
  }
  
  const result = await db
    .select()
    .from(academicEvents)
    .where(or(...conditions)!)
    .orderBy(asc(academicEvents.startDate));
  
  return result;
}

export async function isDateAcademicEvent(date: Date, courseId?: number): Promise<boolean> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const startOfDay = new Date(date);
  startOfDay.setHours(0, 0, 0, 0);
  
  const endOfDay = new Date(date);
  endOfDay.setHours(23, 59, 59, 999);
  
  const conditions = [
    and(
      gte(academicEvents.startDate, startOfDay),
      lte(academicEvents.endDate, endOfDay),
      eq(academicEvents.affectsAttendance, true)
    )!
  ];
  
  if (courseId !== undefined) {
    conditions.push(
      or(
        eq(academicEvents.courseId, courseId),
        isNull(academicEvents.courseId)
      )!
    );
  }
  
  const result = await db
    .select()
    .from(academicEvents)
    .where(or(...conditions)!)
    .limit(1);
  
  return result.length > 0;
}

export async function getAcademicEventsByMonth(year: number, month: number, courseId?: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const startDate = new Date(year, month - 1, 1);
  const endDate = new Date(year, month, 0, 23, 59, 59);
  
  return await getEventsBetweenDates(startDate, endDate, courseId);
}


export async function calculateAttendanceSummaryWithEvents(
  studentId: number,
  courseId: number,
  month: number,
  year: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Obtener todos los registros de asistencia del mes
  const startDate = new Date(year, month - 1, 1);
  const endDate = new Date(year, month, 0, 23, 59, 59);
  
  const attendanceRecords = await db
    .select()
    .from(attendances)
    .where(
      and(
        eq(attendances.studentId, studentId),
        eq(attendances.courseId, courseId),
        gte(attendances.date, startDate),
        lte(attendances.date, endDate)
      )!
    );
  
  // Obtener eventos académicos que afectan asistencia
  const events = await getEventsBetweenDates(startDate, endDate, courseId);
  const eventDates = new Set<string>();
  
  events.forEach(event => {
    if (event.affectsAttendance) {
      const current = new Date(event.startDate);
      const end = new Date(event.endDate);
      
      while (current <= end) {
        eventDates.add(current.toISOString().split('T')[0]);
        current.setDate(current.getDate() + 1);
      }
    }
  });
  
  // Calcular estadísticas excluyendo días de eventos
  let totalDays = 0;
  let presentDays = 0;
  let absentDays = 0;
  let justifiedDays = 0;
  let lateDays = 0;
  
  attendanceRecords.forEach((record: Attendance) => {
    const dateStr = new Date(record.date).toISOString().split('T')[0];
    
    // No contar si es un día de evento académico
    if (eventDates.has(dateStr)) {
      return;
    }
    
    totalDays++;
    
    switch (record.status) {
      case 'presente':
        presentDays++;
        break;
      case 'ausente':
        absentDays++;
        break;
      case 'justificado':
        justifiedDays++;
        break;
      case 'tarde':
        lateDays++;
        presentDays++; // Contar como presente
        break;
    }
  });
  
  const absencePercentage = totalDays > 0 
    ? ((absentDays / totalDays) * 100).toFixed(2)
    : '0';
  
  return {
    totalDays,
    presentDays,
    absentDays,
    justifiedDays,
    lateDays,
    absencePercentage: parseFloat(absencePercentage),
  };
}
