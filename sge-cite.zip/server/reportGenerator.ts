import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { Student, Subject } from '../drizzle/schema';

interface StudentStatistics {
  totalStudents: number;
  averageApproval: number;
  byShift: Record<string, number>;
  byYear: Record<number, number>;
}

/**
 * Genera un PDF con el listado de estudiantes y estadísticas
 */
export async function generateStudentsPDF(
  students: Student[],
  stats: StudentStatistics
): Promise<Buffer> {
  const doc = new jsPDF();
  
  // Título
  doc.setFontSize(18);
  doc.text('SGE-CITE - Reporte de Estudiantes', 14, 20);
  doc.setFontSize(12);
  doc.text('EES N°6 René Favaloro - General Rodríguez', 14, 28);
  
  // Fecha
  doc.setFontSize(10);
  doc.text(`Fecha: ${new Date().toLocaleDateString('es-AR')}`, 14, 35);
  
  // Estadísticas generales
  doc.setFontSize(14);
  doc.text('Estadísticas Generales', 14, 45);
  
  doc.setFontSize(10);
  doc.text(`Total de estudiantes: ${stats.totalStudents}`, 14, 52);
  doc.text(`Promedio de aprobación: ${stats.averageApproval}%`, 14, 58);
  
  // Tabla de estudiantes
  const tableData = students.map(s => [
    `${s.lastName}, ${s.firstName}`,
    s.dni,
    `${s.year}°${s.division}`,
    s.shift,
    `${s.approvalPercentage}%`,
    s.studentPhone || '-',
  ]);
  
  autoTable(doc, {
    startY: 65,
    head: [['Nombre', 'DNI', 'Curso', 'Turno', 'Aprobación', 'Teléfono']],
    body: tableData,
    styles: { fontSize: 8 },
    headStyles: { fillColor: [41, 128, 185] },
  });
  
  return Buffer.from(doc.output('arraybuffer'));
}

/**
 * Genera un archivo Excel con el listado completo de estudiantes
 */
export async function generateStudentsExcel(
  students: Array<Student & { subjects: Subject[] }>
): Promise<Buffer> {
  const workbook = XLSX.utils.book_new();
  
  // Hoja principal con todos los estudiantes
  const mainData = students.map(s => {
    const pendientes = s.subjects.filter(sub => sub.status === 'pendiente').map(sub => sub.subjectName).join(', ');
    const recursadas = s.subjects.filter(sub => sub.status === 'recursada').map(sub => sub.subjectName).join(', ');
    const intensificadas = s.subjects.filter(sub => sub.status === 'intensificada').map(sub => sub.subjectName).join(', ');
    
    return {
      'Apellido': s.lastName,
      'Nombre': s.firstName,
      'DNI': s.dni,
      'Año': s.year,
      'División': s.division,
      'Turno': s.shift,
      'Teléfono Alumno': s.studentPhone || '',
      'Teléfono Padres': s.parentPhone || '',
      'Dirección': s.address || '',
      'Libro': s.enrollmentBook || '',
      'Folio': s.enrollmentFolio || '',
      'Aprobación %': s.approvalPercentage,
      'Materias Pendientes': pendientes,
      'Materias Recursadas': recursadas,
      'Materias Intensificadas': intensificadas,
    };
  });
  
  const mainSheet = XLSX.utils.json_to_sheet(mainData);
  XLSX.utils.book_append_sheet(workbook, mainSheet, 'Estudiantes');
  
  // Agrupar por turno y crear hojas separadas
  const byShift = {
    'mañana': students.filter(s => s.shift === 'mañana'),
    'tarde': students.filter(s => s.shift === 'tarde'),
    'vespertino': students.filter(s => s.shift === 'vespertino'),
  };
  
  for (const [shift, shiftStudents] of Object.entries(byShift)) {
    if (shiftStudents.length === 0) continue;
    
    const shiftData = shiftStudents.map(s => ({
      'Apellido y Nombre': `${s.lastName}, ${s.firstName}`,
      'DNI': s.dni,
      'Curso': `${s.year}°${s.division}`,
      'Aprobación %': s.approvalPercentage,
      'Teléfono': s.studentPhone || '',
    }));
    
    const shiftSheet = XLSX.utils.json_to_sheet(shiftData);
    XLSX.utils.book_append_sheet(workbook, shiftSheet, `Turno ${shift.charAt(0).toUpperCase() + shift.slice(1)}`);
  }
  
  // Convertir a buffer
  const excelBuffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
  return excelBuffer;
}
