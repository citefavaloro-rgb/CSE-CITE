import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Dashboard from "./pages/Dashboard";
import Students from "./pages/Students";
import StudentDetail from "./pages/StudentDetail";
import Import from "./pages/Import";
import Reports from "./pages/Reports";
import Attendance from "./pages/Attendance";
import AttendanceStudentReport from "./pages/AttendanceStudentReport";
import AttendanceCourseReport from "./pages/AttendanceCourseReport";
import AttendanceImport from "./pages/AttendanceImport";
import AcademicCalendar from "./pages/AcademicCalendar";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/students" component={Students} />
      <Route path="/students/:id" component={StudentDetail} />
      <Route path="/import" component={Import} />
      <Route path="/reports" component={Reports} />
      <Route path="/attendance" component={Attendance} />
      <Route path="/attendance/import" component={AttendanceImport} />
      <Route path="/attendance/student-report" component={AttendanceStudentReport} />
      <Route path="/attendance/course-report" component={AttendanceCourseReport} />
      <Route path="/calendar" component={AcademicCalendar} />
      {/* Fallback */}
      <Route component={Dashboard} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
