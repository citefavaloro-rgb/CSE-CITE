import { useState } from "react";
import { useRoute, Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Edit, Plus, Trash2, UserCheck, FileText, Phone, MapPin } from "lucide-react";
import { toast } from "sonner";

export default function StudentDetail() {
  const [, params] = useRoute("/students/:id");
  const studentId = params?.id ? parseInt(params.id) : 0;
  const { user } = useAuth();
  
  const { data: student, isLoading, refetch } = trpc.students.get.useQuery({ id: studentId });
  const updateMutation = trpc.students.update.useMutation();
  const createSubjectMutation = trpc.subjects.create.useMutation();
  const deleteSubjectMutation = trpc.subjects.delete.useMutation();
  const createAuthorizedMutation = trpc.authorizedPersons.create.useMutation();
  const deleteAuthorizedMutation = trpc.authorizedPersons.delete.useMutation();
  
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState<any>({});
  
  const [showAddSubject, setShowAddSubject] = useState(false);
  const [newSubject, setNewSubject] = useState({
    subjectName: "",
    year: studentId,
    status: "pendiente" as "pendiente" | "recursada" | "intensificada" | "aprobada",
  });
  
  const [showAddAuthorized, setShowAddAuthorized] = useState(false);
  const [newAuthorized, setNewAuthorized] = useState({
    firstName: "",
    lastName: "",
    dni: "",
    relationship: "",
    phone: "",
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!student) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card>
          <CardHeader>
            <CardTitle>Estudiante no encontrado</CardTitle>
            <CardDescription>
              El estudiante que buscas no existe o fue eliminado
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Link href="/students">
              <Button>Volver al listado</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleSaveEdit = async () => {
    try {
      await updateMutation.mutateAsync({
        id: studentId,
        ...editData,
      });
      toast.success("Datos actualizados correctamente");
      setIsEditing(false);
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Error al actualizar");
    }
  };

  const handleAddSubject = async () => {
    try {
      await createSubjectMutation.mutateAsync({
        studentId,
        ...newSubject,
        year: student.year,
      });
      toast.success("Materia agregada correctamente");
      setShowAddSubject(false);
      setNewSubject({ subjectName: "", year: student.year, status: "pendiente" });
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Error al agregar materia");
    }
  };

  const handleDeleteSubject = async (subjectId: number) => {
    if (!confirm("¿Estás seguro de eliminar esta materia?")) return;
    
    try {
      await deleteSubjectMutation.mutateAsync({ id: subjectId });
      toast.success("Materia eliminada");
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Error al eliminar");
    }
  };

  const handleAddAuthorized = async () => {
    try {
      await createAuthorizedMutation.mutateAsync({
        studentId,
        ...newAuthorized,
      });
      toast.success("Persona autorizada agregada");
      setShowAddAuthorized(false);
      setNewAuthorized({ firstName: "", lastName: "", dni: "", relationship: "", phone: "" });
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Error al agregar");
    }
  };

  const handleDeleteAuthorized = async (authorizedId: number) => {
    if (!confirm("¿Estás seguro de eliminar esta persona autorizada?")) return;
    
    try {
      await deleteAuthorizedMutation.mutateAsync({ id: authorizedId });
      toast.success("Persona autorizada eliminada");
      refetch();
    } catch (error: any) {
      toast.error(error.message || "Error al eliminar");
    }
  };

  const pendingSubjects = student.subjects?.filter(s => s.status === "pendiente") || [];
  const recursadasSubjects = student.subjects?.filter(s => s.status === "recursada") || [];
  const intensificadasSubjects = student.subjects?.filter(s => s.status === "intensificada") || [];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/students">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-foreground">
                  {student.lastName}, {student.firstName}
                </h1>
                <p className="text-sm text-muted-foreground">
                  DNI: {student.dni} • {student.year}°{student.division} • Turno {student.shift}
                </p>
              </div>
            </div>
            {user?.role === 'admin' && (
              <Button onClick={() => setIsEditing(!isEditing)}>
                <Edit className="h-4 w-4 mr-2" />
                {isEditing ? "Cancelar" : "Editar"}
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <Tabs defaultValue="personal" className="space-y-6">
          <TabsList>
            <TabsTrigger value="personal">Datos Personales</TabsTrigger>
            <TabsTrigger value="academic">Historial Académico</TabsTrigger>
            <TabsTrigger value="authorized">Personas Autorizadas</TabsTrigger>
            <TabsTrigger value="documents">Documentos</TabsTrigger>
          </TabsList>

          {/* Datos Personales */}
          <TabsContent value="personal">
            <Card>
              <CardHeader>
                <CardTitle>Información Personal</CardTitle>
                <CardDescription>
                  Datos de contacto y ubicación del estudiante
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isEditing ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label>Nombre</Label>
                        <Input
                          value={editData.firstName ?? student.firstName}
                          onChange={(e) => setEditData({ ...editData, firstName: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label>Apellido</Label>
                        <Input
                          value={editData.lastName ?? student.lastName}
                          onChange={(e) => setEditData({ ...editData, lastName: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label>DNI</Label>
                        <Input
                          value={editData.dni ?? student.dni}
                          onChange={(e) => setEditData({ ...editData, dni: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label>Teléfono Alumno</Label>
                        <Input
                          value={editData.studentPhone ?? student.studentPhone ?? ""}
                          onChange={(e) => setEditData({ ...editData, studentPhone: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label>Teléfono Padres</Label>
                        <Input
                          value={editData.parentPhone ?? student.parentPhone ?? ""}
                          onChange={(e) => setEditData({ ...editData, parentPhone: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label>Dirección</Label>
                        <Input
                          value={editData.address ?? student.address ?? ""}
                          onChange={(e) => setEditData({ ...editData, address: e.target.value })}
                        />
                      </div>
                    </div>
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" onClick={() => setIsEditing(false)}>
                        Cancelar
                      </Button>
                      <Button onClick={handleSaveEdit}>
                        Guardar Cambios
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="flex items-start gap-3">
                      <Phone className="h-5 w-5 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">Teléfono Alumno</p>
                        <p className="text-sm text-muted-foreground">
                          {student.studentPhone || "No registrado"}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Phone className="h-5 w-5 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">Teléfono Padres</p>
                        <p className="text-sm text-muted-foreground">
                          {student.parentPhone || "No registrado"}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 md:col-span-2">
                      <MapPin className="h-5 w-5 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">Dirección</p>
                        <p className="text-sm text-muted-foreground">
                          {student.address || "No registrada"}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <FileText className="h-5 w-5 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">Libro de Inscripción</p>
                        <p className="text-sm text-muted-foreground">
                          {student.enrollmentBook || "No registrado"}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <FileText className="h-5 w-5 text-muted-foreground mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">Folio</p>
                        <p className="text-sm text-muted-foreground">
                          {student.enrollmentFolio || "No registrado"}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Historial Académico */}
          <TabsContent value="academic">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Rendimiento Académico</CardTitle>
                      <CardDescription>
                        Porcentaje de materias aprobadas
                      </CardDescription>
                    </div>
                    <div className="text-right">
                      <div className="text-3xl font-bold">{student.approvalPercentage}%</div>
                      <p className="text-sm text-muted-foreground">Aprobación</p>
                    </div>
                  </div>
                </CardHeader>
              </Card>

              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Materias Pendientes</CardTitle>
                    {user?.role === 'admin' && (
                      <Dialog open={showAddSubject} onOpenChange={setShowAddSubject}>
                        <DialogTrigger asChild>
                          <Button size="sm">
                            <Plus className="h-4 w-4 mr-2" />
                            Agregar Materia
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Agregar Materia</DialogTitle>
                            <DialogDescription>
                              Registra una nueva materia para el estudiante
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div>
                              <Label>Nombre de la Materia</Label>
                              <Input
                                value={newSubject.subjectName}
                                onChange={(e) => setNewSubject({ ...newSubject, subjectName: e.target.value })}
                              />
                            </div>
                            <div>
                              <Label>Estado</Label>
                              <Select
                                value={newSubject.status}
                                onValueChange={(value: any) => setNewSubject({ ...newSubject, status: value })}
                              >
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="pendiente">Pendiente</SelectItem>
                                  <SelectItem value="recursada">Recursada</SelectItem>
                                  <SelectItem value="intensificada">Intensificada</SelectItem>
                                  <SelectItem value="aprobada">Aprobada</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                          <DialogFooter>
                            <Button variant="outline" onClick={() => setShowAddSubject(false)}>
                              Cancelar
                            </Button>
                            <Button onClick={handleAddSubject}>
                              Agregar
                            </Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  {pendingSubjects.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No hay materias pendientes</p>
                  ) : (
                    <div className="space-y-2">
                      {pendingSubjects.map((subject) => (
                        <div key={subject.id} className="flex items-center justify-between p-3 border border-border rounded-lg">
                          <span className="text-sm font-medium">{subject.subjectName}</span>
                          {user?.role === 'admin' && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteSubject(subject.id)}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Materias Recursadas</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {recursadasSubjects.length === 0 ? (
                      <p className="text-sm text-muted-foreground">No hay materias recursadas</p>
                    ) : (
                      <div className="space-y-2">
                        {recursadasSubjects.map((subject) => (
                          <div key={subject.id} className="flex items-center justify-between p-3 border border-border rounded-lg">
                            <span className="text-sm font-medium">{subject.subjectName}</span>
                            {user?.role === 'admin' && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDeleteSubject(subject.id)}
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Materias Intensificadas</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {intensificadasSubjects.length === 0 ? (
                      <p className="text-sm text-muted-foreground">No hay materias intensificadas</p>
                    ) : (
                      <div className="space-y-2">
                        {intensificadasSubjects.map((subject) => (
                          <div key={subject.id} className="flex items-center justify-between p-3 border border-border rounded-lg">
                            <span className="text-sm font-medium">{subject.subjectName}</span>
                            {user?.role === 'admin' && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDeleteSubject(subject.id)}
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                              </Button>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Personas Autorizadas */}
          <TabsContent value="authorized">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Personas Autorizadas para Retiro</CardTitle>
                    <CardDescription>
                      Personas autorizadas a retirar al estudiante de la institución
                    </CardDescription>
                  </div>
                  {user?.role === 'admin' && (
                    <Dialog open={showAddAuthorized} onOpenChange={setShowAddAuthorized}>
                      <DialogTrigger asChild>
                        <Button>
                          <Plus className="h-4 w-4 mr-2" />
                          Agregar Persona
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Agregar Persona Autorizada</DialogTitle>
                          <DialogDescription>
                            Registra una persona autorizada para retirar al estudiante
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <Label>Nombre</Label>
                              <Input
                                value={newAuthorized.firstName}
                                onChange={(e) => setNewAuthorized({ ...newAuthorized, firstName: e.target.value })}
                              />
                            </div>
                            <div>
                              <Label>Apellido</Label>
                              <Input
                                value={newAuthorized.lastName}
                                onChange={(e) => setNewAuthorized({ ...newAuthorized, lastName: e.target.value })}
                              />
                            </div>
                          </div>
                          <div>
                            <Label>DNI</Label>
                            <Input
                              value={newAuthorized.dni}
                              onChange={(e) => setNewAuthorized({ ...newAuthorized, dni: e.target.value })}
                            />
                          </div>
                          <div>
                            <Label>Parentesco</Label>
                            <Input
                              placeholder="Ej: Padre, Madre, Tutor, Abuelo..."
                              value={newAuthorized.relationship}
                              onChange={(e) => setNewAuthorized({ ...newAuthorized, relationship: e.target.value })}
                            />
                          </div>
                          <div>
                            <Label>Teléfono</Label>
                            <Input
                              value={newAuthorized.phone}
                              onChange={(e) => setNewAuthorized({ ...newAuthorized, phone: e.target.value })}
                            />
                          </div>
                        </div>
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setShowAddAuthorized(false)}>
                            Cancelar
                          </Button>
                          <Button onClick={handleAddAuthorized}>
                            Agregar
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {!student.authorizedPersons || student.authorizedPersons.length === 0 ? (
                  <p className="text-sm text-muted-foreground">
                    No hay personas autorizadas registradas
                  </p>
                ) : (
                  <div className="space-y-4">
                    {student.authorizedPersons.map((person) => (
                      <div key={person.id} className="flex items-start justify-between p-4 border border-border rounded-lg">
                        <div className="flex items-start gap-3">
                          <UserCheck className="h-5 w-5 text-muted-foreground mt-0.5" />
                          <div>
                            <p className="font-medium">
                              {person.lastName}, {person.firstName}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              DNI: {person.dni}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Parentesco: {person.relationship}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Teléfono: {person.phone}
                            </p>
                          </div>
                        </div>
                        {user?.role === 'admin' && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteAuthorized(person.id)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Documentos */}
          <TabsContent value="documents">
            <Card>
              <CardHeader>
                <CardTitle>Documentos Adjuntos</CardTitle>
                <CardDescription>
                  Certificados, autorizaciones y otros documentos del legajo
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Funcionalidad de documentos en desarrollo
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
