import { useState, useRef, useCallback, useEffect } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Upload, FileSpreadsheet, CheckCircle, XCircle, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { Progress } from "@/components/ui/progress";

export default function Import() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<any>(null);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const parseExcelMutation = trpc.import.parseExcel.useMutation();
  const executeImportMutation = trpc.import.executeImport.useMutation();

  const handleFileSelect = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    if (!['xlsx', 'xls', 'docx', 'pdf'].some(ext => selectedFile.name.toLowerCase().endsWith('.' + ext))) {
      toast.error("Por favor selecciona un archivo válido (Excel, Word o PDF)");
      return;
    }

    setFile(selectedFile);
    setImportResult(null);

    // Convertir a base64 y parsear
    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const base64 = event.target?.result?.toString().split(',')[1];
        if (!base64) return;

        const result = await parseExcelMutation.mutateAsync({
          fileContent: base64,
          fileName: selectedFile.name,
        });

        setPreview(result);
        toast.success(`${result.count} registros encontrados en el archivo`);
      } catch (error: any) {
        toast.error(error.message || "Error al procesar el archivo");
        setFile(null);
      }
    };
    reader.readAsDataURL(selectedFile);
  }, [parseExcelMutation]);

  const handleImport = useCallback(async () => {
    if (!file || !preview) return;

    if (!confirm(`¿Estás seguro de importar ${preview.count} registros? Esta acción puede sobrescribir datos existentes.`)) {
      return;
    }

    setImporting(true);

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const base64 = event.target?.result?.toString().split(',')[1];
        if (!base64) return;

        const result = await executeImportMutation.mutateAsync({
          fileContent: base64,
          fileName: file.name,
        });

        setImportResult(result);
        
        if (result.success) {
          toast.success(`Importación completada: ${result.recordsImported} registros importados`);
        } else {
          toast.warning(`Importación completada con errores: ${result.recordsImported} importados, ${result.recordsFailed} fallidos`);
        }
      } catch (error: any) {
        toast.error(error.message || "Error al importar datos");
      } finally {
        setImporting(false);
      }
    };
    reader.readAsDataURL(file);
  }, [file, preview, executeImportMutation]);

  const handleReset = useCallback(() => {
    setFile(null);
    setPreview(null);
    setImportResult(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  }, []);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Importación Masiva</h1>
              <p className="text-sm text-muted-foreground">
                Carga datos desde archivos Excel, Word o PDF
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Instructions */}
          <Card>
            <CardHeader>
              <CardTitle>Instrucciones</CardTitle>
              <CardDescription>
                Cómo preparar tu archivo Excel para la importación
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 text-sm">
                <div>
                  <h4 className="font-medium mb-2">Formato del archivo:</h4>
                  <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                    <li>El archivo debe estar en formato .xlsx, .xls, .docx o .pdf</li>
                    <li>Cada hoja debe representar un curso (ej: 1A, 2B, 3C)</li>
                    <li>El nombre de la hoja debe seguir el formato: [Año][División] (ej: 1A, 2B)</li>
                    <li>Agregar hojas separadoras con "TURNO MAÑANA", "TURNO TARDE", "TURNO VESPERTINO"</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Columnas requeridas:</h4>
                  <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                    <li><strong>APELLIDO Y NOMBRE</strong>: Nombre completo del estudiante</li>
                    <li><strong>INTENSIFICA 1</strong> o <strong>INTENSIFICA 2</strong>: Materias intensificadas (opcional)</li>
                    <li><strong>RECURSA 1</strong> o <strong>RECURSA 2</strong>: Materias recursadas (opcional)</li>
                    <li><strong>LIBRO</strong>: Número de libro de inscripción (opcional)</li>
                    <li><strong>FOLIO</strong>: Número de folio (opcional)</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Upload Section */}
          {!importResult && (
            <Card>
              <CardHeader>
                <CardTitle>Seleccionar Archivo</CardTitle>
                <CardDescription>
                  Sube tu archivo Excel para comenzar la importación
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-center w-full">
                    <label className="flex flex-col items-center justify-center w-full h-64 border-2 border-dashed border-border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors">
                      <div className="flex flex-col items-center justify-center pt-5 pb-6">
                        {file ? (
                          <>
                            <FileSpreadsheet className="w-12 h-12 mb-4 text-primary" />
                            <p className="mb-2 text-sm font-medium">{file.name}</p>
                            <p className="text-xs text-muted-foreground">
                              {(file.size / 1024).toFixed(2)} KB
                            </p>
                            {preview && (
                              <p className="mt-2 text-sm text-primary font-medium">
                                {preview.count} registros encontrados
                              </p>
                            )}
                          </>
                        ) : (
                          <>
                            <Upload className="w-12 h-12 mb-4 text-muted-foreground" />
                            <p className="mb-2 text-sm text-muted-foreground">
                              <span className="font-semibold">Click para seleccionar</span> o arrastra el archivo
                            </p>
                            <p className="text-xs text-muted-foreground">
                              Archivos (Excel, Word, PDF) (.xlsx, .xls)
                            </p>
                          </>
                        )}
                      </div>
                      <input
                        ref={fileInputRef}
                        type="file"
                        className="hidden"
                        accept=".xlsx,.xls,.docx,.pdf"
                        onChange={handleFileSelect}
                      />
                    </label>
                  </div>

                  {file && preview && (
                    <div className="flex gap-2">
                      <Button
                        onClick={handleImport}
                        disabled={importing}
                        className="flex-1"
                      >
                        {importing ? "Importando..." : "Iniciar Importación"}
                      </Button>
                      <Button
                        variant="outline"
                        onClick={handleReset}
                        disabled={importing}
                      >
                        Cancelar
                      </Button>
                    </div>
                  )}

                  {importing && (
                    <div className="space-y-2">
                      <Progress value={50} />
                      <p className="text-sm text-center text-muted-foreground">
                        Procesando datos, por favor espera...
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Results */}
          {importResult && (
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  {importResult.success ? (
                    <CheckCircle className="h-6 w-6 text-green-600" />
                  ) : (
                    <AlertCircle className="h-6 w-6 text-yellow-600" />
                  )}
                  <div>
                    <CardTitle>
                      {importResult.success ? "Importación Exitosa" : "Importación Completada con Advertencias"}
                    </CardTitle>
                    <CardDescription>
                      Resumen de la importación de datos
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 border border-border rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <CheckCircle className="h-5 w-5 text-green-600" />
                        <span className="text-sm font-medium">Registros Importados</span>
                      </div>
                      <p className="text-2xl font-bold">{importResult.recordsImported}</p>
                    </div>
                    <div className="p-4 border border-border rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <XCircle className="h-5 w-5 text-red-600" />
                        <span className="text-sm font-medium">Registros Fallidos</span>
                      </div>
                      <p className="text-2xl font-bold">{importResult.recordsFailed}</p>
                    </div>
                  </div>

                  {importResult.errors && importResult.errors.length > 0 && (
                    <div>
                      <h4 className="font-medium mb-2">Errores Encontrados:</h4>
                      <div className="max-h-60 overflow-y-auto space-y-2">
                        {importResult.errors.slice(0, 10).map((error: any, index: number) => (
                          <div key={index} className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg text-sm">
                            <p className="font-medium">Fila {error.row}: {error.error}</p>
                            {error.data && (
                              <p className="text-xs text-muted-foreground mt-1">
                                {JSON.stringify(error.data).substring(0, 100)}...
                              </p>
                            )}
                          </div>
                        ))}
                        {importResult.errors.length > 10 && (
                          <p className="text-sm text-muted-foreground text-center">
                            Y {importResult.errors.length - 10} errores más...
                          </p>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="flex gap-2">
                    <Link href="/students">
                      <Button className="flex-1">
                        Ver Estudiantes Importados
                      </Button>
                    </Link>
                    <Button variant="outline" onClick={handleReset}>
                      Nueva Importación
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}
