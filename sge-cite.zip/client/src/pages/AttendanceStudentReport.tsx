import { useState } from "react";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Download, AlertTriangle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

export default function AttendanceStudentReport() {
  const { user } = useAuth();
  const [selectedStudentId, setSelectedStudentId] = useState<string>("");

  const { data: students } = trpc.students.list.useQuery({ limit: 1000 });
  const { data: report } = trpc.attendances.getStudentReport.useQuery(
    { studentId: parseInt(selectedStudentId) },
    { enabled: !!selectedStudentId }
  );

  const selectedStudent = students?.students.find(s => s.id === parseInt(selectedStudentId));

  const monthlyData = report?.monthlySummaries.map(summary => ({
    month: new Date(2024, summary.month - 1).toLocaleDateString('es-AR', { month: 'long' }),
    ausencias: summary.absentDays || 0,
    justificadas: summary.justifiedDays || 0,
    presentes: summary.presentDays || 0,
    tardes: summary.lateDays || 0,
  })) || [];

  const absenceRatio = report ? [
    { name: "Presentes", value: report.monthlySummaries.reduce((sum, s) => sum + (s.presentDays || 0), 0), color: "#22c55e" },
    { name: "Ausentes", value: report.totalAbsences, color: "#ef4444" },
    { name: "Justificadas", value: report.totalJustified, color: "#eab308" },
  ] : [];

  const handleDownloadReport = () => {
    if (!selectedStudent || !report) return;

    const csvContent = [
      ["Reporte de Ausentismo"],
      ["Estudiante:", `${selectedStudent.lastName}, ${selectedStudent.firstName}`],
      ["DNI:", selectedStudent.dni],
      ["Año/División:", `${selectedStudent.year}°${selectedStudent.division}`],
      ["Turno:", selectedStudent.shift],
      [""],
      ["Mes", "Total Días", "Presentes", "Ausentes", "Justificadas", "Tardes", "% Ausencias"],
      ...report.monthlySummaries.map(s => [
        new Date(2024, s.month - 1).toLocaleDateString('es-AR', { month: 'long' }),
        s.totalDays || 0,
        s.presentDays || 0,
        s.absentDays || 0,
        s.justifiedDays || 0,
        s.lateDays || 0,
        `${s.absencePercentage}%`,
      ]),
      [""],
      ["TOTALES:", "", 
        report.monthlySummaries.reduce((sum, s) => sum + (s.presentDays || 0), 0),
        report.totalAbsences,
        report.totalJustified,
        report.monthlySummaries.reduce((sum, s) => sum + (s.lateDays || 0), 0),
      ],
    ].map(row => row.join(",")).join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `ausentismo-${selectedStudent.lastName}-${selectedStudent.firstName}.csv`;
    link.click();
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Reporte de Ausentismo por Estudiante</h1>
              <p className="text-sm text-muted-foreground">
                Análisis detallado de inasistencias por alumno
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="space-y-6">
          {/* Student Selection */}
          <Card>
            <CardHeader>
              <CardTitle>Seleccionar Estudiante</CardTitle>
            </CardHeader>
            <CardContent>
              <Select value={selectedStudentId} onValueChange={setSelectedStudentId}>
                <SelectTrigger>
                  <SelectValue placeholder="Busca un estudiante..." />
                </SelectTrigger>
                <SelectContent>
                  {students?.students.map((student) => (
                    <SelectItem key={student.id} value={student.id.toString()}>
                      {student.lastName}, {student.firstName} - {student.year}°{student.division}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          {selectedStudent && report && (
            <>
              {/* Student Info */}
              <Card>
                <CardHeader>
                  <CardTitle>{selectedStudent.lastName}, {selectedStudent.firstName}</CardTitle>
                  <CardDescription>
                    DNI: {selectedStudent.dni} | {selectedStudent.year}°{selectedStudent.division} - {selectedStudent.shift}
                  </CardDescription>
                </CardHeader>
              </Card>

              {/* Statistics */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Total de Ausencias
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-red-600">
                      {report.totalAbsences}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Ausencias Justificadas
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-yellow-600">
                      {report.totalJustified}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Meses Registrados
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {report.monthlySummaries.length}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Promedio Ausencias
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {report.monthlySummaries.length > 0 
                        ? Math.round(report.totalAbsences / report.monthlySummaries.length)
                        : 0
                      }
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Alert if high absences */}
              {report.totalAbsences > 10 && (
                <Card className="border-red-200 bg-red-50">
                  <CardContent className="pt-6 flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-red-900">
                        Alerta: Alto porcentaje de inasistencias
                      </p>
                      <p className="text-sm text-red-700 mt-1">
                        Este estudiante tiene más de 10 ausencias registradas. Se recomienda contactar a los padres/tutores.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Charts */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Monthly Attendance */}
                <Card>
                  <CardHeader>
                    <CardTitle>Asistencias por Mes</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {monthlyData.length > 0 ? (
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={monthlyData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="month" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Bar dataKey="presentes" fill="#22c55e" name="Presentes" />
                          <Bar dataKey="ausencias" fill="#ef4444" name="Ausencias" />
                          <Bar dataKey="justificadas" fill="#eab308" name="Justificadas" />
                          <Bar dataKey="tardes" fill="#f97316" name="Tardes" />
                        </BarChart>
                      </ResponsiveContainer>
                    ) : (
                      <p className="text-center text-muted-foreground py-8">
                        Sin datos de asistencia
                      </p>
                    )}
                  </CardContent>
                </Card>

                {/* Absence Ratio */}
                <Card>
                  <CardHeader>
                    <CardTitle>Distribución de Asistencias</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {absenceRatio.length > 0 ? (
                      <ResponsiveContainer width="100%" height={300}>
                        <PieChart>
                          <Pie
                            data={absenceRatio}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, value }) => `${name}: ${value}`}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {absenceRatio.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    ) : (
                      <p className="text-center text-muted-foreground py-8">
                        Sin datos de asistencia
                      </p>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Monthly Details Table */}
              {monthlyData.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Detalle Mensual</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead className="border-b border-border">
                          <tr className="bg-muted">
                            <th className="text-left p-2 font-semibold">Mes</th>
                            <th className="text-center p-2 font-semibold">Total</th>
                            <th className="text-center p-2 font-semibold text-green-600">Presentes</th>
                            <th className="text-center p-2 font-semibold text-red-600">Ausentes</th>
                            <th className="text-center p-2 font-semibold text-yellow-600">Justificadas</th>
                            <th className="text-center p-2 font-semibold text-orange-600">Tardes</th>
                          </tr>
                        </thead>
                        <tbody>
                          {report.monthlySummaries.map((summary, idx) => (
                            <tr key={idx} className="border-b border-border hover:bg-muted/50">
                              <td className="p-2">
                                {new Date(2024, summary.month - 1).toLocaleDateString('es-AR', { month: 'long' })}
                              </td>
                              <td className="text-center p-2">{summary.totalDays || 0}</td>
                              <td className="text-center p-2 text-green-600">{summary.presentDays || 0}</td>
                              <td className="text-center p-2 text-red-600">{summary.absentDays || 0}</td>
                              <td className="text-center p-2 text-yellow-600">{summary.justifiedDays || 0}</td>
                              <td className="text-center p-2 text-orange-600">{summary.lateDays || 0}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Download Button */}
              <div className="flex justify-end">
                <Button onClick={handleDownloadReport} className="gap-2">
                  <Download className="h-4 w-4" />
                  Descargar Reporte CSV
                </Button>
              </div>
            </>
          )}

          {selectedStudentId && !report && (
            <Card>
              <CardContent className="py-12 text-center">
                <p className="text-muted-foreground">
                  Cargando datos de asistencia...
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}
