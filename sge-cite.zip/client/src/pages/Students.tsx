import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Link } from "wouter";
import { Search, Eye, Plus, FileDown, ArrowLeft } from "lucide-react";
import { toast } from "sonner";

export default function Students() {
  const { user } = useAuth();
  const [search, setSearch] = useState("");
  const [year, setYear] = useState<string>("");
  const [division, setDivision] = useState<string>("");
  const [shift, setShift] = useState<string>("");
  const [filterType, setFilterType] = useState<string>("");
  
  const { data, isLoading } = trpc.students.list.useQuery({
    search: search || undefined,
    year: year ? parseInt(year) : undefined,
    division: division || undefined,
    shift: shift as any || undefined,
    hasPendingSubjects: filterType === "pending" ? true : undefined,
    hasRecursadas: filterType === "recursadas" ? true : undefined,
    hasIntensificadas: filterType === "intensificadas" ? true : undefined,
    sortBy: "name",
    sortOrder: "asc",
  });

  const students = data?.students || [];
  const total = data?.total || 0;

  const handleClearFilters = () => {
    setSearch("");
    setYear("");
    setDivision("");
    setShift("");
    setFilterType("");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Estudiantes</h1>
                <p className="text-sm text-muted-foreground">
                  Gestión de estudiantes del sistema
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {user?.role === 'admin' && (
                <Link href="/students/new">
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Nuevo Estudiante
                  </Button>
                </Link>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="space-y-6">
          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle>Filtros de Búsqueda</CardTitle>
              <CardDescription>
                Filtra y busca estudiantes por diferentes criterios
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
                <div className="xl:col-span-2">
                  <label className="text-sm font-medium mb-2 block">Buscar</label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Nombre, apellido o DNI..."
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Año</label>
                  <Select value={year} onValueChange={setYear}>
                    <SelectTrigger>
                      <SelectValue placeholder="Todos" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value=" ">Todos</SelectItem>
                      <SelectItem value="1">1° Año</SelectItem>
                      <SelectItem value="2">2° Año</SelectItem>
                      <SelectItem value="3">3° Año</SelectItem>
                      <SelectItem value="4">4° Año</SelectItem>
                      <SelectItem value="5">5° Año</SelectItem>
                      <SelectItem value="6">6° Año</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">División</label>
                  <Select value={division} onValueChange={setDivision}>
                    <SelectTrigger>
                      <SelectValue placeholder="Todas" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value=" ">Todas</SelectItem>
                      <SelectItem value="A">A</SelectItem>
                      <SelectItem value="B">B</SelectItem>
                      <SelectItem value="C">C</SelectItem>
                      <SelectItem value="D">D</SelectItem>
                      <SelectItem value="E">E</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Turno</label>
                  <Select value={shift} onValueChange={setShift}>
                    <SelectTrigger>
                      <SelectValue placeholder="Todos" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value=" ">Todos</SelectItem>
                      <SelectItem value="mañana">Mañana</SelectItem>
                      <SelectItem value="tarde">Tarde</SelectItem>
                      <SelectItem value="vespertino">Vespertino</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Estado</label>
                  <Select value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger>
                      <SelectValue placeholder="Todos" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value=" ">Todos</SelectItem>
                      <SelectItem value="pending">Con Pendientes</SelectItem>
                      <SelectItem value="recursadas">Con Recursadas</SelectItem>
                      <SelectItem value="intensificadas">Con Intensificadas</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex justify-end mt-4">
                <Button variant="outline" onClick={handleClearFilters}>
                  Limpiar Filtros
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Results */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Resultados</CardTitle>
                  <CardDescription>
                    {total} estudiante{total !== 1 ? 's' : ''} encontrado{total !== 1 ? 's' : ''}
                  </CardDescription>
                </div>
                {user?.role === 'admin' && (
                  <Link href="/reports">
                    <Button variant="outline" size="sm">
                      <FileDown className="h-4 w-4 mr-2" />
                      Exportar
                    </Button>
                  </Link>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex items-center justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                </div>
              ) : students.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">
                    No se encontraron estudiantes con los filtros aplicados
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Apellido y Nombre</th>
                        <th>DNI</th>
                        <th>Curso</th>
                        <th>Turno</th>
                        <th>Aprobación</th>
                        <th>Teléfono</th>
                        <th className="text-right">Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                      {students.map((student) => (
                        <tr key={student.id}>
                          <td className="font-medium">
                            {student.lastName}, {student.firstName}
                          </td>
                          <td>{student.dni}</td>
                          <td>{student.year}°{student.division}</td>
                          <td className="capitalize">{student.shift}</td>
                          <td>
                            <span
                              className={`badge ${
                                (student.approvalPercentage || 0) >= 70
                                  ? 'badge-success'
                                  : (student.approvalPercentage || 0) >= 50
                                  ? 'badge-warning'
                                  : 'badge-danger'
                              }`}
                            >
                              {student.approvalPercentage || 0}%
                            </span>
                          </td>
                          <td>{student.studentPhone || '-'}</td>
                          <td className="text-right">
                            <Link href={`/students/${student.id}`}>
                              <Button variant="ghost" size="sm">
                                <Eye className="h-4 w-4 mr-1" />
                                Ver Legajo
                              </Button>
                            </Link>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
