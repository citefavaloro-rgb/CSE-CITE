import { useState } from "react";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Download, AlertTriangle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

export default function AttendanceCourseReport() {
  const { user } = useAuth();
  const [selectedCourse, setSelectedCourse] = useState<string>("");
  const [selectedMonth, setSelectedMonth] = useState<string>("");
  const [selectedYear, setSelectedYear] = useState<string>(new Date().getFullYear().toString());

  const { data: courses } = trpc.courses.list.useQuery();
  const { data: students } = trpc.students.list.useQuery({ limit: 1000 });
  
  const { data: courseReport } = trpc.attendances.getCourseReport.useQuery(
    {
      courseId: parseInt(selectedCourse),
      month: selectedMonth ? parseInt(selectedMonth) : undefined,
      year: parseInt(selectedYear),
    },
    { enabled: !!selectedCourse }
  );

  const selectedCourseData = courses?.find(c => c.id === parseInt(selectedCourse));

  const months = Array.from({ length: 12 }, (_, i) => ({
    value: (i + 1).toString(),
    label: new Date(2024, i).toLocaleDateString('es-AR', { month: 'long' }),
  }));

  const years = Array.from({ length: 5 }, (_, i) => ({
    value: (new Date().getFullYear() - i).toString(),
    label: (new Date().getFullYear() - i).toString(),
  }));

  const courseReportData = courseReport?.map(summary => {
    const student = students?.students.find(s => s.id === summary.studentId);
    return {
      studentName: student ? `${student.lastName}, ${student.firstName}` : "Desconocido",
      totalDays: summary.totalDays || 0,
      presentes: summary.presentDays || 0,
      ausencias: summary.absentDays || 0,
      justificadas: summary.justifiedDays || 0,
      tardes: summary.lateDays || 0,
      porcentajeAusencias: summary.absencePercentage || 0,
    };
  }) || [];

  const totalStats = courseReportData.reduce(
    (acc, row) => ({
      totalDays: acc.totalDays + row.totalDays,
      presentes: acc.presentes + row.presentes,
      ausencias: acc.ausencias + row.ausencias,
      justificadas: acc.justificadas + row.justificadas,
      tardes: acc.tardes + row.tardes,
    }),
    { totalDays: 0, presentes: 0, ausencias: 0, justificadas: 0, tardes: 0 }
  );

  const handleDownloadReport = () => {
    if (!selectedCourseData || !courseReport) return;

    const csvContent = [
      ["Reporte de Ausentismo por Curso"],
      ["Curso:", `${selectedCourseData.year}°${selectedCourseData.division} - ${selectedCourseData.shift}`],
      selectedMonth ? ["Mes:", months.find(m => m.value === selectedMonth)?.label] : [],
      ["Año:", selectedYear],
      [""],
      ["Estudiante", "Total Días", "Presentes", "Ausentes", "Justificadas", "Tardes", "% Ausencias"],
      ...courseReportData.map(row => [
        row.studentName,
        row.totalDays,
        row.presentes,
        row.ausencias,
        row.justificadas,
        row.tardes,
        `${row.porcentajeAusencias}%`,
      ]),
      [""],
      ["TOTALES:", totalStats.totalDays, totalStats.presentes, totalStats.ausencias, totalStats.justificadas, totalStats.tardes],
    ].filter(row => row.length > 0).map(row => row.join(",")).join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `ausentismo-curso-${selectedCourseData.year}${selectedCourseData.division}.csv`;
    link.click();
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Reporte de Ausentismo por Curso</h1>
              <p className="text-sm text-muted-foreground">
                Análisis de inasistencias por curso y período
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="space-y-6">
          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle>Filtros</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="text-sm font-medium">Curso</label>
                  <Select value={selectedCourse} onValueChange={setSelectedCourse}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona un curso" />
                    </SelectTrigger>
                    <SelectContent>
                      {courses?.map((course) => (
                        <SelectItem key={course.id} value={course.id.toString()}>
                          {course.year}°{course.division} - {course.shift}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium">Mes (Opcional)</label>
                  <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                    <SelectTrigger>
                      <SelectValue placeholder="Todos los meses" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Todos los meses</SelectItem>
                      {months.map((month) => (
                        <SelectItem key={month.value} value={month.value}>
                          {month.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium">Año</label>
                  <Select value={selectedYear} onValueChange={setSelectedYear}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {years.map((year) => (
                        <SelectItem key={year.value} value={year.value}>
                          {year.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-end">
                  <Button onClick={handleDownloadReport} disabled={!selectedCourse} className="w-full gap-2">
                    <Download className="h-4 w-4" />
                    Descargar CSV
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {selectedCourse && selectedCourseData && (
            <>
              {/* Course Info */}
              <Card>
                <CardHeader>
                  <CardTitle>
                    {selectedCourseData.year}°{selectedCourseData.division} - {selectedCourseData.shift}
                  </CardTitle>
                  <CardDescription>
                    {selectedMonth 
                      ? `${months.find(m => m.value === selectedMonth)?.label} de ${selectedYear}`
                      : `Año ${selectedYear}`
                    }
                  </CardDescription>
                </CardHeader>
              </Card>

              {/* Statistics */}
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-xs font-medium text-muted-foreground">
                      Total de Días
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {totalStats.totalDays}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-xs font-medium text-muted-foreground">
                      Presentes
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-green-600">
                      {totalStats.presentes}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-xs font-medium text-muted-foreground">
                      Ausencias
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-red-600">
                      {totalStats.ausencias}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-xs font-medium text-muted-foreground">
                      Justificadas
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-yellow-600">
                      {totalStats.justificadas}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-xs font-medium text-muted-foreground">
                      Tardes
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold text-orange-600">
                      {totalStats.tardes}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Alert for high absences */}
              {courseReportData.some(row => Number(row.porcentajeAusencias) > 30) && (
                <Card className="border-red-200 bg-red-50">
                  <CardContent className="pt-6 flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-red-900">
                        Alerta: Estudiantes con alto ausentismo
                      </p>
                      <p className="text-sm text-red-700 mt-1">
                        {courseReportData.filter(row => Number(row.porcentajeAusencias) > 30).length} estudiante(s) tienen más del 30% de ausencias.
                      </p>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Chart */}
              {courseReportData.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Asistencias por Estudiante</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={400}>
                      <BarChart data={courseReportData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="studentName" angle={-45} textAnchor="end" height={100} />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="presentes" fill="#22c55e" name="Presentes" />
                        <Bar dataKey="ausencias" fill="#ef4444" name="Ausencias" />
                        <Bar dataKey="justificadas" fill="#eab308" name="Justificadas" />
                        <Bar dataKey="tardes" fill="#f97316" name="Tardes" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              )}

              {/* Detailed Table */}
              {courseReportData.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Detalle por Estudiante</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead className="border-b border-border">
                          <tr className="bg-muted">
                            <th className="text-left p-2 font-semibold">Estudiante</th>
                            <th className="text-center p-2 font-semibold">Total</th>
                            <th className="text-center p-2 font-semibold text-green-600">Presentes</th>
                            <th className="text-center p-2 font-semibold text-red-600">Ausencias</th>
                            <th className="text-center p-2 font-semibold text-yellow-600">Justificadas</th>
                            <th className="text-center p-2 font-semibold text-orange-600">Tardes</th>
                            <th className="text-center p-2 font-semibold">% Ausencias</th>
                          </tr>
                        </thead>
                        <tbody>
                          {courseReportData.map((row, idx) => (
                            <tr 
                              key={idx} 
                              className={`border-b border-border hover:bg-muted/50 ${
                                Number(row.porcentajeAusencias) > 30 ? 'bg-red-50' : ''
                              }`}
                            >
                              <td className="p-2 font-medium">{row.studentName}</td>
                              <td className="text-center p-2">{row.totalDays}</td>
                              <td className="text-center p-2 text-green-600">{row.presentes}</td>
                              <td className="text-center p-2 text-red-600">{row.ausencias}</td>
                              <td className="text-center p-2 text-yellow-600">{row.justificadas}</td>
                              <td className="text-center p-2 text-orange-600">{row.tardes}</td>
                              <td className="text-center p-2 font-semibold">{row.porcentajeAusencias}%</td>
                            </tr>
                          ))}
                          <tr className="border-t-2 border-border bg-muted font-semibold">
                            <td className="p-2">TOTALES</td>
                            <td className="text-center p-2">{totalStats.totalDays}</td>
                            <td className="text-center p-2 text-green-600">{totalStats.presentes}</td>
                            <td className="text-center p-2 text-red-600">{totalStats.ausencias}</td>
                            <td className="text-center p-2 text-yellow-600">{totalStats.justificadas}</td>
                            <td className="text-center p-2 text-orange-600">{totalStats.tardes}</td>
                            <td className="text-center p-2">
                              {totalStats.totalDays > 0 
                                ? Math.round((totalStats.ausencias / totalStats.totalDays) * 100)
                                : 0
                              }%
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              )}

              {courseReportData.length === 0 && (
                <Card>
                  <CardContent className="py-12 text-center">
                    <p className="text-muted-foreground">
                      No hay datos de asistencia para este curso en el período seleccionado
                    </p>
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </div>
      </main>
    </div>
  );
}
