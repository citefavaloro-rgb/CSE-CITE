import { useState } from "react";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Plus, Trash2, Edit2, Calendar } from "lucide-react";
import { toast } from "sonner";

interface FormData {
  title: string;
  description: string;
  eventType: "feriado" | "receso" | "examen" | "acto_escolar" | "reunion_padres" | "jornada_pedagogica" | "otro";
  startDate: string;
  endDate: string;
  affectsAttendance: boolean;
  courseId?: number;
  color: string;
}

const EVENT_COLORS: Record<string, { bg: string; border: string; text: string }> = {
  "#ef4444": { bg: "bg-red-50", border: "border-red-200", text: "text-red-700" },
  "#f97316": { bg: "bg-orange-50", border: "border-orange-200", text: "text-orange-700" },
  "#eab308": { bg: "bg-yellow-50", border: "border-yellow-200", text: "text-yellow-700" },
  "#22c55e": { bg: "bg-green-50", border: "border-green-200", text: "text-green-700" },
  "#3b82f6": { bg: "bg-blue-50", border: "border-blue-200", text: "text-blue-700" },
  "#8b5cf6": { bg: "bg-purple-50", border: "border-purple-200", text: "text-purple-700" },
};

const EVENT_TYPES = {
  feriado: "Feriado",
  receso: "Receso",
  examen: "Exámenes",
  acto_escolar: "Acto Escolar",
  reunion_padres: "Reunión de Padres",
  jornada_pedagogica: "Jornada Pedagógica",
  otro: "Otro",
};

export default function AcademicCalendar() {
  const { user } = useAuth();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedCourse, setSelectedCourse] = useState<string>("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<any>(null);
  const [formData, setFormData] = useState<FormData>({
    title: "",
    description: "",
    eventType: "feriado",
    startDate: "",
    endDate: "",
    affectsAttendance: true,
    color: "#3b82f6",
  });

  const { data: courses } = trpc.courses.list.useQuery();
  const { data: events } = trpc.academicEvents.getByMonth.useQuery({
    year: currentDate.getFullYear(),
    month: currentDate.getMonth() + 1,
    courseId: selectedCourse ? parseInt(selectedCourse) : undefined,
  });

  const createMutation = trpc.academicEvents.create.useMutation();
  const updateMutation = trpc.academicEvents.update.useMutation();
  const deleteMutation = trpc.academicEvents.delete.useMutation();

  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
  };

  const handleOpenDialog = (event?: any) => {
    if (event) {
      setEditingEvent(event);
      setFormData({
        title: event.title,
        description: event.description || "",
        eventType: event.eventType,
        startDate: event.startDate.toISOString().split('T')[0],
        endDate: event.endDate.toISOString().split('T')[0],
        affectsAttendance: event.affectsAttendance,
        courseId: event.courseId || undefined,
        color: event.color,
      });
    } else {
      setEditingEvent(null);
      setFormData({
        title: "",
        description: "",
        eventType: "feriado",
        startDate: "",
        endDate: "",
        affectsAttendance: true,
        color: "#3b82f6",
      });
    }
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    if (!formData.title || !formData.startDate || !formData.endDate) {
      toast.error("Completa los campos obligatorios");
      return;
    }

    try {
      if (editingEvent) {
        await updateMutation.mutateAsync({
          id: editingEvent.id,
          ...formData,
          startDate: new Date(formData.startDate),
          endDate: new Date(formData.endDate),
        });
        toast.success("Evento actualizado");
      } else {
        await createMutation.mutateAsync({
          ...formData,
          startDate: new Date(formData.startDate),
          endDate: new Date(formData.endDate),
        });
        toast.success("Evento creado");
      }
      setIsDialogOpen(false);
    } catch (error) {
      toast.error("Error al guardar el evento");
      console.error(error);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("¿Estás seguro de que deseas eliminar este evento?")) return;

    try {
      await deleteMutation.mutateAsync(id);
      toast.success("Evento eliminado");
    } catch (error) {
      toast.error("Error al eliminar el evento");
      console.error(error);
    }
  };

  const getDaysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const daysInMonth = getDaysInMonth(currentDate);
  const firstDay = getFirstDayOfMonth(currentDate);
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const emptyDays = Array.from({ length: firstDay }, (_, i) => i);

  const getEventsForDay = (day: number) => {
    if (!events) return [];
    const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    return events.filter(event => {
      const eventStart = new Date(event.startDate);
      const eventEnd = new Date(event.endDate);
      return date >= eventStart && date <= eventEnd;
    });
  };

  const monthName = currentDate.toLocaleString('es-AR', { month: 'long', year: 'numeric' });

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Calendario Académico</h1>
              <p className="text-sm text-muted-foreground">
                Gestiona feriados, exámenes y eventos escolares
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="space-y-6">
          {/* Controls */}
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
            <div className="flex gap-4 items-center">
              <Button variant="outline" onClick={handlePrevMonth}>
                ← Anterior
              </Button>
              <h2 className="text-xl font-semibold capitalize min-w-48">{monthName}</h2>
              <Button variant="outline" onClick={handleNextMonth}>
                Siguiente →
              </Button>
            </div>

            {user?.role === 'admin' && (
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button onClick={() => handleOpenDialog()} className="gap-2">
                    <Plus className="h-4 w-4" />
                    Nuevo Evento
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>{editingEvent ? "Editar Evento" : "Crear Evento"}</DialogTitle>
                    <DialogDescription>
                      Agrega un nuevo evento al calendario académico
                    </DialogDescription>
                  </DialogHeader>

                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="title">Título *</Label>
                      <Input
                        id="title"
                        value={formData.title}
                        onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                        placeholder="Ej: Feriado Nacional"
                      />
                    </div>

                    <div>
                      <Label htmlFor="description">Descripción</Label>
                      <Textarea
                        id="description"
                        value={formData.description}
                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                        placeholder="Detalles adicionales"
                        rows={3}
                      />
                    </div>

                    <div>
                      <Label htmlFor="eventType">Tipo de Evento *</Label>
                      <Select value={formData.eventType} onValueChange={(value) => setFormData({ ...formData, eventType: value as any })}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {Object.entries(EVENT_TYPES).map(([key, label]) => (
                            <SelectItem key={key} value={key}>{label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="startDate">Fecha Inicio *</Label>
                        <Input
                          id="startDate"
                          type="date"
                          value={formData.startDate}
                          onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="endDate">Fecha Fin *</Label>
                        <Input
                          id="endDate"
                          type="date"
                          value={formData.endDate}
                          onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="color">Color</Label>
                      <div className="flex gap-2 flex-wrap">
                        {Object.keys(EVENT_COLORS).map((color) => (
                          <button
                            key={color}
                            onClick={() => setFormData({ ...formData, color })}
                            className={`w-8 h-8 rounded border-2 ${formData.color === color ? 'border-foreground' : 'border-transparent'}`}
                            style={{ backgroundColor: color }}
                          />
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        id="affectsAttendance"
                        checked={formData.affectsAttendance}
                        onChange={(e) => setFormData({ ...formData, affectsAttendance: e.target.checked })}
                        className="rounded"
                      />
                      <Label htmlFor="affectsAttendance" className="cursor-pointer">
                        Excluir del cálculo de asistencias
                      </Label>
                    </div>

                    <div className="flex gap-2 justify-end">
                      <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                        Cancelar
                      </Button>
                      <Button onClick={handleSave}>
                        {editingEvent ? "Actualizar" : "Crear"}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            )}
          </div>

          {/* Calendar Grid */}
          <Card>
            <CardContent className="pt-6">
              {/* Day Headers */}
              <div className="grid grid-cols-7 gap-2 mb-2">
                {["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"].map((day) => (
                  <div key={day} className="text-center font-semibold text-sm text-muted-foreground py-2">
                    {day}
                  </div>
                ))}
              </div>

              {/* Empty Days */}
              {emptyDays.map((_, i) => (
                <div key={`empty-${i}`} className="aspect-square" />
              ))}

              {/* Days */}
              {days.map((day) => {
                const dayEvents = getEventsForDay(day);
                return (
                  <div
                    key={day}
                    className="aspect-square border border-border rounded-lg p-2 hover:bg-muted/50 transition overflow-hidden"
                  >
                    <div className="text-sm font-semibold mb-1">{day}</div>
                    <div className="space-y-1 text-xs overflow-y-auto max-h-20">
                      {dayEvents.map((event) => {
                        const colors = EVENT_COLORS[event.color || "#3b82f6"];
                        return (
                          <div
                            key={event.id}
                            className={`${colors?.bg} ${colors?.border} border rounded px-1 py-0.5 truncate cursor-pointer group relative`}
                            onClick={() => user?.role === 'admin' && handleOpenDialog(event)}
                          >
                            <div className={`${colors?.text} truncate`}>
                              {event.title}
                            </div>
                            {user?.role === 'admin' && (
                              <div className="hidden group-hover:flex gap-1 absolute top-0 right-0 bg-background border rounded">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleOpenDialog(event);
                                  }}
                                  className="p-1 hover:bg-muted"
                                >
                                  <Edit2 className="h-3 w-3" />
                                </button>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleDelete(event.id);
                                  }}
                                  className="p-1 hover:bg-red-50"
                                >
                                  <Trash2 className="h-3 w-3 text-red-600" />
                                </button>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </CardContent>
          </Card>

          {/* Events List */}
          {events && events.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Eventos de {monthName}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {events.map((event) => {
                    const colors = EVENT_COLORS[event.color || "#3b82f6"];
                    const startDate = new Date(event.startDate).toLocaleDateString('es-AR');
                    const endDate = new Date(event.endDate).toLocaleDateString('es-AR');
                    return (
                      <div
                        key={event.id}
                        className={`${colors?.bg} ${colors?.border} border rounded-lg p-4`}
                      >
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <h3 className={`font-semibold ${colors?.text}`}>
                              {event.title}
                            </h3>
                            {event.description && (
                              <p className="text-sm text-muted-foreground mt-1">
                                {event.description}
                              </p>
                            )}
                            <div className="flex gap-4 mt-2 text-sm">
                              <span className={colors.text}>
                                {startDate} {startDate !== endDate && `- ${endDate}`}
                              </span>
                              <span className="text-muted-foreground">
                                {EVENT_TYPES[event.eventType as keyof typeof EVENT_TYPES]}
                              </span>
                              {event.affectsAttendance && (
                                <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded">
                                  Excluido de asistencias
                                </span>
                              )}
                            </div>
                          </div>
                          {user?.role === 'admin' && (
                            <div className="flex gap-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleOpenDialog(event)}
                              >
                                <Edit2 className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDelete(event.id)}
                              >
                                <Trash2 className="h-4 w-4 text-red-600" />
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}
