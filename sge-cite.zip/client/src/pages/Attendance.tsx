import { useState } from "react";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowLeft, Check, X, Clock, FileText } from "lucide-react";
import { toast } from "sonner";

export default function Attendance() {
  const { user } = useAuth();
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedCourse, setSelectedCourse] = useState<string>("");
  const [attendanceData, setAttendanceData] = useState<Record<number, { status: string; notes: string }>>({});

  const { data: courses } = trpc.courses.list.useQuery();
  const { data: students } = trpc.students.list.useQuery({
    year: selectedCourse ? parseInt(selectedCourse.split('-')[0]) : undefined,
    division: selectedCourse ? selectedCourse.split('-')[1] : undefined,
  });

  const recordAttendanceMutation = trpc.attendances.record.useMutation();

  const handleStatusChange = (studentId: number, status: string) => {
    setAttendanceData(prev => ({
      ...prev,
      [studentId]: { ...prev[studentId], status, notes: prev[studentId]?.notes || "" }
    }));
  };

  const handleNotesChange = (studentId: number, notes: string) => {
    setAttendanceData(prev => ({
      ...prev,
      [studentId]: { ...prev[studentId], notes, status: prev[studentId]?.status || "presente" }
    }));
  };

  const handleSaveAttendance = async () => {
    if (!selectedCourse || !selectedDate) {
      toast.error("Selecciona curso y fecha");
      return;
    }

    const [year, division] = selectedCourse.split('-');
    const course = courses?.find(c => c.year === parseInt(year) && c.division === division);
    
    if (!course) {
      toast.error("Curso no encontrado");
      return;
    }

    let saved = 0;
    let errors = 0;

    for (const [studentId, data] of Object.entries(attendanceData)) {
      if (!data.status) continue;

      try {
        await recordAttendanceMutation.mutateAsync({
          studentId: parseInt(studentId),
          courseId: course.id,
          date: new Date(selectedDate),
          status: data.status as any,
          notes: data.notes || undefined,
        });
        saved++;
      } catch (error) {
        errors++;
      }
    }

    if (saved > 0) {
      toast.success(`${saved} asistencias registradas`);
      setAttendanceData({});
    }
    if (errors > 0) {
      toast.error(`${errors} errores al guardar`);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "presente":
        return <Check className="h-4 w-4 text-green-600" />;
      case "ausente":
        return <X className="h-4 w-4 text-red-600" />;
      case "justificado":
        return <FileText className="h-4 w-4 text-yellow-600" />;
      case "tarde":
        return <Clock className="h-4 w-4 text-orange-600" />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Registro de Asistencias</h1>
              <p className="text-sm text-muted-foreground">
                Registra la asistencia diaria de los estudiantes
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="space-y-6">
          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle>Seleccionar Curso y Fecha</CardTitle>
              <CardDescription>
                Elige el curso y la fecha para registrar asistencias
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label>Fecha</Label>
                  <Input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                  />
                </div>

                <div>
                  <Label>Curso</Label>
                  <Select value={selectedCourse} onValueChange={setSelectedCourse}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona un curso" />
                    </SelectTrigger>
                    <SelectContent>
                      {courses?.map((course) => (
                        <SelectItem key={course.id} value={`${course.year}-${course.division}`}>
                          {course.year}°{course.division} - {course.shift}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-end">
                  <Button onClick={handleSaveAttendance} className="w-full">
                    Guardar Asistencias
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Attendance List */}
          {selectedCourse && students && students.students.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Estudiantes</CardTitle>
                <CardDescription>
                  {students.students.length} estudiantes en este curso
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {students.students.map((student) => {
                    const data = attendanceData[student.id];
                    return (
                      <div key={student.id} className="flex items-center gap-4 p-3 border border-border rounded-lg">
                        <div className="flex-1">
                          <p className="font-medium">
                            {student.lastName}, {student.firstName}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            DNI: {student.dni}
                          </p>
                        </div>

                        <div className="flex items-center gap-2">
                          <Select
                            value={data?.status || ""}
                            onValueChange={(value) => handleStatusChange(student.id, value)}
                          >
                            <SelectTrigger className="w-32">
                              <SelectValue placeholder="Estado" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="presente">
                                <div className="flex items-center gap-2">
                                  <Check className="h-4 w-4 text-green-600" />
                                  Presente
                                </div>
                              </SelectItem>
                              <SelectItem value="ausente">
                                <div className="flex items-center gap-2">
                                  <X className="h-4 w-4 text-red-600" />
                                  Ausente
                                </div>
                              </SelectItem>
                              <SelectItem value="justificado">
                                <div className="flex items-center gap-2">
                                  <FileText className="h-4 w-4 text-yellow-600" />
                                  Justificado
                                </div>
                              </SelectItem>
                              <SelectItem value="tarde">
                                <div className="flex items-center gap-2">
                                  <Clock className="h-4 w-4 text-orange-600" />
                                  Llegó Tarde
                                </div>
                              </SelectItem>
                            </SelectContent>
                          </Select>

                          {data?.status && getStatusIcon(data.status)}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {selectedCourse && students && students.students.length === 0 && (
            <Card>
              <CardContent className="py-12 text-center">
                <p className="text-muted-foreground">
                  No hay estudiantes en este curso
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </main>
    </div>
  );
}
