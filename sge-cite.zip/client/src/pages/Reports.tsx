import { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, FileText, FileSpreadsheet, Download } from "lucide-react";
import { toast } from "sonner";

export default function Reports() {
  const [year, setYear] = useState<string>("");
  const [division, setDivision] = useState<string>("");
  const [shift, setShift] = useState<string>("");
  const [generating, setGenerating] = useState(false);

  const generatePDFMutation = trpc.reports.generatePDF.useMutation();
  const generateExcelMutation = trpc.reports.generateExcel.useMutation();

  const handleGeneratePDF = async () => {
    setGenerating(true);
    try {
      const result = await generatePDFMutation.mutateAsync({
        filters: {
          year: year ? parseInt(year) : undefined,
          division: division || undefined,
          shift: shift as any || undefined,
        },
      });

      // Abrir el PDF en una nueva pestaña
      window.open(result.url, '_blank');
      toast.success("Reporte PDF generado correctamente");
    } catch (error: any) {
      toast.error(error.message || "Error al generar reporte PDF");
    } finally {
      setGenerating(false);
    }
  };

  const handleGenerateExcel = async () => {
    setGenerating(true);
    try {
      const result = await generateExcelMutation.mutateAsync({
        filters: {
          year: year ? parseInt(year) : undefined,
          division: division || undefined,
          shift: shift as any || undefined,
        },
      });

      // Descargar el archivo Excel
      window.open(result.url, '_blank');
      toast.success("Reporte Excel generado correctamente");
    } catch (error: any) {
      toast.error(error.message || "Error al generar reporte Excel");
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Reportes</h1>
              <p className="text-sm text-muted-foreground">
                Genera reportes en PDF y Excel con estadísticas
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle>Filtros de Reporte</CardTitle>
              <CardDescription>
                Selecciona los criterios para generar el reporte
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Año</label>
                  <Select value={year} onValueChange={setYear}>
                    <SelectTrigger>
                      <SelectValue placeholder="Todos los años" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value=" ">Todos los años</SelectItem>
                      <SelectItem value="1">1° Año</SelectItem>
                      <SelectItem value="2">2° Año</SelectItem>
                      <SelectItem value="3">3° Año</SelectItem>
                      <SelectItem value="4">4° Año</SelectItem>
                      <SelectItem value="5">5° Año</SelectItem>
                      <SelectItem value="6">6° Año</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">División</label>
                  <Select value={division} onValueChange={setDivision}>
                    <SelectTrigger>
                      <SelectValue placeholder="Todas las divisiones" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value=" ">Todas las divisiones</SelectItem>
                      <SelectItem value="A">A</SelectItem>
                      <SelectItem value="B">B</SelectItem>
                      <SelectItem value="C">C</SelectItem>
                      <SelectItem value="D">D</SelectItem>
                      <SelectItem value="E">E</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium mb-2 block">Turno</label>
                  <Select value={shift} onValueChange={setShift}>
                    <SelectTrigger>
                      <SelectValue placeholder="Todos los turnos" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value=" ">Todos los turnos</SelectItem>
                      <SelectItem value="mañana">Mañana</SelectItem>
                      <SelectItem value="tarde">Tarde</SelectItem>
                      <SelectItem value="vespertino">Vespertino</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Report Types */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-primary/10 rounded-lg">
                    <FileText className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle>Reporte PDF</CardTitle>
                    <CardDescription>
                      Documento con estadísticas y listado
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-sm text-muted-foreground">
                    <p className="mb-2">El reporte PDF incluye:</p>
                    <ul className="list-disc list-inside space-y-1">
                      <li>Estadísticas generales</li>
                      <li>Listado completo de estudiantes</li>
                      <li>Datos de contacto</li>
                      <li>Porcentaje de aprobación</li>
                    </ul>
                  </div>
                  <Button
                    onClick={handleGeneratePDF}
                    disabled={generating}
                    className="w-full"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    {generating ? "Generando..." : "Generar PDF"}
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-green-100 dark:bg-green-900 rounded-lg">
                    <FileSpreadsheet className="h-6 w-6 text-green-600 dark:text-green-400" />
                  </div>
                  <div>
                    <CardTitle>Reporte Excel</CardTitle>
                    <CardDescription>
                      Planilla editable con datos completos
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-sm text-muted-foreground">
                    <p className="mb-2">El reporte Excel incluye:</p>
                    <ul className="list-disc list-inside space-y-1">
                      <li>Datos personales completos</li>
                      <li>Materias pendientes, recursadas e intensificadas</li>
                      <li>Hojas separadas por turno</li>
                      <li>Formato editable</li>
                    </ul>
                  </div>
                  <Button
                    onClick={handleGenerateExcel}
                    disabled={generating}
                    className="w-full"
                    variant="outline"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    {generating ? "Generando..." : "Generar Excel"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Info */}
          <Card>
            <CardHeader>
              <CardTitle>Información Adicional</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm text-muted-foreground">
                <p>
                  Los reportes se generan en tiempo real con los datos actuales del sistema.
                </p>
                <p>
                  Puedes aplicar filtros para generar reportes específicos por año, división o turno.
                </p>
                <p>
                  Los archivos generados se almacenan temporalmente y pueden ser descargados múltiples veces.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
