import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, TrendingUp, AlertCircle, BookOpen, Clock, Upload, Calendar } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Dashboard() {
  const { user, loading: authLoading } = useAuth();
  const { data: stats, isLoading: statsLoading } = trpc.statistics.dashboard.useQuery();

  if (authLoading || statsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Acceso Restringido</CardTitle>
            <CardDescription>
              Debes iniciar sesión para acceder al sistema
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">SGE-CITE</h1>
              <p className="text-sm text-muted-foreground">
                Sistema de Gestión Estudiantil - EES N°6 René Favaloro
              </p>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right">
                <p className="text-sm font-medium">{user.name}</p>
                <p className="text-xs text-muted-foreground">
                  {user.role === 'admin' ? 'Coordinador CITE' : 'Preceptor'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="space-y-8">
          {/* Welcome Section */}
          <div>
            <h2 className="text-3xl font-bold mb-2">
              Bienvenido, {user.name?.split(' ')[0]}
            </h2>
            <p className="text-muted-foreground">
              Panel de control del Sistema de Gestión Estudiantil
            </p>
          </div>

          {/* Statistics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total de Estudiantes
                </CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats?.totalStudents || 0}</div>
                <p className="text-xs text-muted-foreground">
                  Registrados en el sistema
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Promedio de Aprobación
                </CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats?.averageApproval || 0}%</div>
                <p className="text-xs text-muted-foreground">
                  Rendimiento general
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Alumnos en Riesgo
                </CardTitle>
                <AlertCircle className="h-4 w-4 text-destructive" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-destructive">
                  {stats?.studentsAtRiskCount || 0}
                </div>
                <p className="text-xs text-muted-foreground">
                  Menos del 50% de aprobación
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Con Materias Pendientes
                </CardTitle>
                <BookOpen className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {stats?.studentsWithPendingCount || 0}
                </div>
                <p className="text-xs text-muted-foreground">
                  Requieren seguimiento
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Distribution by Shift */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Distribución por Turno</CardTitle>
                <CardDescription>
                  Cantidad de estudiantes por turno
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {stats?.byShift && Object.entries(stats.byShift).map(([shift, count]) => (
                    <div key={shift} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-primary"></div>
                        <span className="text-sm font-medium capitalize">{shift}</span>
                      </div>
                      <span className="text-sm font-bold">{count}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Distribución por Año</CardTitle>
                <CardDescription>
                  Cantidad de estudiantes por año
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {stats?.byYear && Object.entries(stats.byYear)
                    .sort(([a], [b]) => Number(a) - Number(b))
                    .map(([year, count]) => (
                      <div key={year} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-primary"></div>
                          <span className="text-sm font-medium">{year}° Año</span>
                        </div>
                        <span className="text-sm font-bold">{count}</span>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Acciones Rápidas</CardTitle>
              <CardDescription>
                Accede a las funciones principales del sistema
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Link href="/students">
                  <Button variant="outline" className="w-full h-auto py-4 flex flex-col items-center gap-2">
                    <Users className="h-6 w-6" />
                    <span>Ver Estudiantes</span>
                  </Button>
                </Link>
                
                <Link href="/attendance">
                  <Button variant="outline" className="w-full h-auto py-4 flex flex-col items-center gap-2">
                    <Clock className="h-6 w-6" />
                    <span>Registrar Asistencias</span>
                  </Button>
                </Link>
                
                {user.role === 'admin' && (
                  <>
                    <Link href="/import">
                      <Button variant="outline" className="w-full h-auto py-4 flex flex-col items-center gap-2">
                        <BookOpen className="h-6 w-6" />
                        <span>Importar Datos</span>
                      </Button>
                    </Link>
                    
                    <Link href="/reports">
                      <Button variant="outline" className="w-full h-auto py-4 flex flex-col items-center gap-2">
                        <TrendingUp className="h-6 w-6" />
                        <span>Generar Reportes</span>
                      </Button>
                    </Link>
                    
                    <Link href="/students?filter=at-risk">
                      <Button variant="outline" className="w-full h-auto py-4 flex flex-col items-center gap-2">
                        <AlertCircle className="h-6 w-6 text-destructive" />
                        <span>Alumnos en Riesgo</span>
                      </Button>
                    </Link>
                    
                    <Link href="/attendance/student-report">
                      <Button variant="outline" className="w-full h-auto py-4 flex flex-col items-center gap-2">
                        <TrendingUp className="h-6 w-6" />
                        <span>Ausentismo por Alumno</span>
                      </Button>
                    </Link>
                    
                    <Link href="/attendance/course-report">
                      <Button variant="outline" className="w-full h-auto py-4 flex flex-col items-center gap-2">
                        <TrendingUp className="h-6 w-6" />
                        <span>Ausentismo por Curso</span>
                      </Button>
                    </Link>
                    
                    <Link href="/attendance/import">
                      <Button variant="outline" className="w-full h-auto py-4 flex flex-col items-center gap-2">
                        <Upload className="h-6 w-6" />
                        <span>Importar Asistencias</span>
                      </Button>
                    </Link>

                    <Link href="/calendar">
                      <Button variant="outline" className="w-full h-auto py-4 flex flex-col items-center gap-2">
                        <Calendar className="h-6 w-6" />
                        <span>Calendario Académico</span>
                      </Button>
                    </Link>
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
