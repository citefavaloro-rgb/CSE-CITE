import { useState, useRef } from "react";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Upload, AlertTriangle, CheckCircle, AlertCircle } from "lucide-react";
import { toast } from "sonner";

interface AttendanceRecord {
  studentName: string;
  studentDni?: string;
  date: string;
  status: 'presente' | 'ausente' | 'justificado' | 'tarde';
  notes?: string;
  errors?: string[];
}

interface PreviewData {
  success: boolean;
  totalRecords: number;
  validRecords: number;
  invalidRecords: number;
  records: AttendanceRecord[];
  errors: string[];
}

export default function AttendanceImport() {
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedCourse, setSelectedCourse] = useState<string>("");
  const [previewData, setPreviewData] = useState<PreviewData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isConfirming, setIsConfirming] = useState(false);

  const { data: courses } = trpc.courses.list.useQuery();
  const importPreviewMutation = trpc.attendances.importPreview.useMutation();
  const importConfirmMutation = trpc.attendances.importConfirm.useMutation();

  // Redirigir si no es admin
  if (user?.role !== 'admin') {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b border-border bg-card">
          <div className="container py-4">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Acceso Denegado</h1>
              </div>
            </div>
          </div>
        </header>
        <main className="container py-8">
          <Card className="border-red-200 bg-red-50">
            <CardContent className="pt-6">
              <p className="text-red-900">
                Solo los administradores pueden importar asistencias.
              </p>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !selectedCourse) {
      toast.error("Selecciona un curso antes de cargar el archivo");
      return;
    }

    setIsLoading(true);
    try {
      const buffer = await file.arrayBuffer();
      const base64 = Buffer.from(buffer).toString('base64');

      const result = await importPreviewMutation.mutateAsync({
        fileBase64: base64,
        courseId: parseInt(selectedCourse),
      });

      setPreviewData(result);

      if (result.success) {
        toast.success(`${result.validRecords} registros válidos encontrados`);
      } else {
        toast.error(`Se encontraron ${result.invalidRecords} registros con errores`);
      }
    } catch (error) {
      toast.error("Error al procesar el archivo");
      console.error(error);
    } finally {
      setIsLoading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleConfirmImport = async () => {
    if (!previewData || !selectedCourse) return;

    const validRecords = previewData.records.filter(r => !r.errors || r.errors.length === 0);
    if (validRecords.length === 0) {
      toast.error("No hay registros válidos para importar");
      return;
    }

    setIsConfirming(true);
    try {
      const result = await importConfirmMutation.mutateAsync({
        courseId: parseInt(selectedCourse),
        records: validRecords,
      });

      toast.success(`Se importaron ${result.successCount} registros correctamente`);
      setPreviewData(null);
      setSelectedCourse("");
    } catch (error) {
      toast.error("Error al importar los registros");
      console.error(error);
    } finally {
      setIsConfirming(false);
    }
  };

  const selectedCourseData = courses?.find(c => c.id === parseInt(selectedCourse));

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-foreground">Importar Asistencias</h1>
              <p className="text-sm text-muted-foreground">
                Carga masivamente asistencias desde un archivo Excel
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-8">
        <div className="space-y-6">
          {/* Instructions */}
          <Card>
            <CardHeader>
              <CardTitle>Formato del archivo Excel</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <p className="text-sm">El archivo debe contener las siguientes columnas:</p>
              <ul className="text-sm space-y-1 list-disc list-inside">
                <li><strong>Columna A:</strong> Nombre del estudiante (requerido)</li>
                <li><strong>Columna B:</strong> DNI del estudiante (opcional)</li>
                <li><strong>Columna C:</strong> Fecha en formato DD/MM/YYYY (requerido)</li>
                <li><strong>Columna D:</strong> Estado: presente, ausente, justificado o tarde (requerido)</li>
                <li><strong>Columna E:</strong> Notas (opcional)</li>
              </ul>
            </CardContent>
          </Card>

          {/* Upload Section */}
          <Card>
            <CardHeader>
              <CardTitle>Seleccionar archivo y curso</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium">Curso</label>
                <Select value={selectedCourse} onValueChange={setSelectedCourse}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona un curso" />
                  </SelectTrigger>
                  <SelectContent>
                    {courses?.map((course) => (
                      <SelectItem key={course.id} value={course.id.toString()}>
                        {course.year}°{course.division} - {course.shift}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium">Archivo Excel</label>
                <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:bg-muted/50 transition cursor-pointer"
                  onClick={() => fileInputRef.current?.click()}>
                  <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-sm font-medium">Haz clic para seleccionar un archivo</p>
                  <p className="text-xs text-muted-foreground">o arrastra un archivo aquí</p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".xlsx,.xls"
                    onChange={handleFileSelect}
                    disabled={!selectedCourse || isLoading}
                    className="hidden"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Preview Section */}
          {previewData && (
            <>
              {/* Summary */}
              <Card>
                <CardHeader>
                  <CardTitle>Resumen de importación</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Total de registros</p>
                      <p className="text-2xl font-bold">{previewData.totalRecords}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Válidos</p>
                      <p className="text-2xl font-bold text-green-600">{previewData.validRecords}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Con errores</p>
                      <p className="text-2xl font-bold text-red-600">{previewData.invalidRecords}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Errors */}
              {previewData.errors.length > 0 && (
                <Card className="border-red-200 bg-red-50">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-red-900">
                      <AlertTriangle className="h-5 w-5" />
                      Errores encontrados
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-1 text-sm text-red-700">
                      {previewData.errors.map((error, idx) => (
                        <li key={idx}>• {error}</li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              )}

              {/* Records Table */}
              <Card>
                <CardHeader>
                  <CardTitle>Vista previa de registros</CardTitle>
                  <CardDescription>
                    Solo se importarán los registros sin errores
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="border-b border-border">
                        <tr className="bg-muted">
                          <th className="text-left p-2 font-semibold">Estudiante</th>
                          <th className="text-left p-2 font-semibold">DNI</th>
                          <th className="text-left p-2 font-semibold">Fecha</th>
                          <th className="text-left p-2 font-semibold">Estado</th>
                          <th className="text-left p-2 font-semibold">Notas</th>
                          <th className="text-left p-2 font-semibold">Estado</th>
                        </tr>
                      </thead>
                      <tbody>
                        {previewData.records.map((record, idx) => {
                          const hasErrors = record.errors && record.errors.length > 0;
                          return (
                            <tr key={idx} className={`border-b border-border ${hasErrors ? 'bg-red-50' : ''}`}>
                              <td className="p-2">{record.studentName}</td>
                              <td className="p-2">{record.studentDni || '-'}</td>
                              <td className="p-2">{record.date}</td>
                              <td className="p-2 capitalize">{record.status}</td>
                              <td className="p-2 text-xs">{record.notes || '-'}</td>
                              <td className="p-2">
                                {hasErrors ? (
                                  <div className="flex items-start gap-1">
                                    <AlertCircle className="h-4 w-4 text-red-600 flex-shrink-0 mt-0.5" />
                                    <div className="text-xs text-red-600">
                                      {record.errors?.map((err, i) => (
                                        <div key={i}>{err}</div>
                                      ))}
                                    </div>
                                  </div>
                                ) : (
                                  <CheckCircle className="h-4 w-4 text-green-600" />
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>

              {/* Action Buttons */}
              <div className="flex gap-4 justify-end">
                <Button
                  variant="outline"
                  onClick={() => setPreviewData(null)}
                  disabled={isConfirming}
                >
                  Cancelar
                </Button>
                <Button
                  onClick={handleConfirmImport}
                  disabled={previewData.validRecords === 0 || isConfirming}
                  className="gap-2"
                >
                  {isConfirming ? "Importando..." : `Importar ${previewData.validRecords} registros`}
                </Button>
              </div>
            </>
          )}
        </div>
      </main>
    </div>
  );
}
