CREATE TABLE `academicEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`eventType` enum('feriado','receso','examen','acto_escolar','reunion_padres','jornada_pedagogica','otro') NOT NULL,
	`startDate` timestamp NOT NULL,
	`endDate` timestamp NOT NULL,
	`affectsAttendance` boolean DEFAULT true,
	`courseId` int,
	`color` varchar(20) DEFAULT '#3b82f6',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdBy` int,
	CONSTRAINT `academicEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `academicEvents` ADD CONSTRAINT `academicEvents_courseId_courses_id_fk` FOREIGN KEY (`courseId`) REFERENCES `courses`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `academicEvents` ADD CONSTRAINT `academicEvents_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;