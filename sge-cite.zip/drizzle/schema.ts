import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, decimal } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Estudiantes de la escuela
 */
export const students = mysqlTable("students", {
  id: int("id").autoincrement().primaryKey(),
  // Datos personales
  firstName: varchar("firstName", { length: 100 }).notNull(),
  lastName: varchar("lastName", { length: 100 }).notNull(),
  dni: varchar("dni", { length: 20 }).notNull().unique(),
  // Datos de contacto
  studentPhone: varchar("studentPhone", { length: 50 }),
  parentPhone: varchar("parentPhone", { length: 50 }),
  address: text("address"),
  // Datos académicos
  year: int("year").notNull(), // 1-6 para secundaria
  division: varchar("division", { length: 10 }).notNull(), // A, B, C, D, E
  shift: mysqlEnum("shift", ["mañana", "tarde", "vespertino"]).notNull(),
  // Datos de inscripción
  enrollmentBook: varchar("enrollmentBook", { length: 50 }),
  enrollmentFolio: varchar("enrollmentFolio", { length: 50 }),
  // Estadísticas
  approvalPercentage: int("approvalPercentage").default(0), // 0-100
  // Metadata
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy").references(() => users.id),
  updatedBy: int("updatedBy").references(() => users.id),
});

export type Student = typeof students.$inferSelect;
export type InsertStudent = typeof students.$inferInsert;

/**
 * Materias por estudiante (pendientes, recursadas, intensificadas)
 */
export const subjects = mysqlTable("subjects", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").notNull().references(() => students.id, { onDelete: "cascade" }),
  subjectName: varchar("subjectName", { length: 200 }).notNull(),
  year: int("year").notNull(), // Año en que cursó/cursa la materia
  status: mysqlEnum("status", ["pendiente", "recursada", "intensificada", "aprobada"]).notNull(),
  notes: text("notes"), // Notas adicionales sobre la materia
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Subject = typeof subjects.$inferSelect;
export type InsertSubject = typeof subjects.$inferInsert;

/**
 * Personas autorizadas para retirar al alumno
 */
export const authorizedPersons = mysqlTable("authorizedPersons", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").notNull().references(() => students.id, { onDelete: "cascade" }),
  firstName: varchar("firstName", { length: 100 }).notNull(),
  lastName: varchar("lastName", { length: 100 }).notNull(),
  dni: varchar("dni", { length: 20 }).notNull(),
  relationship: varchar("relationship", { length: 100 }).notNull(), // Padre, Madre, Tutor, Abuelo, etc.
  phone: varchar("phone", { length: 50 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AuthorizedPerson = typeof authorizedPersons.$inferSelect;
export type InsertAuthorizedPerson = typeof authorizedPersons.$inferInsert;

/**
 * Documentos adjuntos al legajo del alumno
 */
export const documents = mysqlTable("documents", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").notNull().references(() => students.id, { onDelete: "cascade" }),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  fileKey: varchar("fileKey", { length: 500 }).notNull(), // S3 key
  fileUrl: varchar("fileUrl", { length: 1000 }).notNull(), // S3 URL
  fileType: varchar("fileType", { length: 100 }), // MIME type
  fileSize: int("fileSize"), // Tamaño en bytes
  documentType: mysqlEnum("documentType", [
    "certificado_medico",
    "autorizacion",
    "documento_identidad",
    "excel_importacion",
    "otro"
  ]).notNull(),
  description: text("description"),
  uploadedBy: int("uploadedBy").references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Document = typeof documents.$inferSelect;
export type InsertDocument = typeof documents.$inferInsert;

/**
 * Cursos/Divisiones de la escuela
 */
export const courses = mysqlTable("courses", {
  id: int("id").autoincrement().primaryKey(),
  year: int("year").notNull(), // 1-6
  division: varchar("division", { length: 10 }).notNull(), // A, B, C, D, E
  shift: mysqlEnum("shift", ["mañana", "tarde", "vespertino"]).notNull(),
  preceptorId: int("preceptorId").references(() => users.id), // Usuario asignado como preceptor
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Course = typeof courses.$inferSelect;
export type InsertCourse = typeof courses.$inferInsert;

/**
 * Registro de asistencias diarias
 */
export const attendances = mysqlTable("attendances", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").notNull().references(() => students.id, { onDelete: "cascade" }),
  courseId: int("courseId").notNull().references(() => courses.id),
  date: timestamp("date").notNull(), // Fecha de la clase
  status: mysqlEnum("status", ["presente", "ausente", "justificado", "tarde"]).notNull(),
  notes: text("notes"), // Notas sobre la inasistencia
  recordedBy: int("recordedBy").references(() => users.id), // Usuario que registró
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Attendance = typeof attendances.$inferSelect;
export type InsertAttendance = typeof attendances.$inferInsert;

/**
 * Resumen de asistencias por estudiante y período
 */
export const attendanceSummary = mysqlTable("attendanceSummary", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").notNull().references(() => students.id, { onDelete: "cascade" }),
  courseId: int("courseId").notNull().references(() => courses.id),
  month: int("month").notNull(), // 1-12
  year: int("year").notNull(),
  totalDays: int("totalDays").default(0), // Total de días de clase
  presentDays: int("presentDays").default(0), // Días presente
  absentDays: int("absentDays").default(0), // Días ausente
  justifiedDays: int("justifiedDays").default(0), // Días justificados
  lateDays: int("lateDays").default(0), // Días llegó tarde
  absencePercentage: decimal("absencePercentage", { precision: 5, scale: 2 }).default("0"), // Porcentaje de ausencias
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AttendanceSummary = typeof attendanceSummary.$inferSelect;
export type InsertAttendanceSummary = typeof attendanceSummary.$inferInsert;

/**
 * Historial de importaciones masivas
 */
export const importHistory = mysqlTable("importHistory", {
  id: int("id").autoincrement().primaryKey(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  fileKey: varchar("fileKey", { length: 500 }).notNull(),
  fileUrl: varchar("fileUrl", { length: 1000 }).notNull(),
  recordsImported: int("recordsImported").default(0),
  recordsFailed: int("recordsFailed").default(0),
  status: mysqlEnum("status", ["pending", "processing", "completed", "failed"]).notNull(),
  errorLog: text("errorLog"),
  importedBy: int("importedBy").references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ImportHistory = typeof importHistory.$inferSelect;
export type InsertImportHistory = typeof importHistory.$inferInsert;


/**
 * Eventos académicos (feriados, exámenes, recesos, etc.)
 */
export const academicEvents = mysqlTable("academicEvents", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  eventType: mysqlEnum("eventType", [
    "feriado",           // Feriado nacional/provincial
    "receso",            // Receso escolar
    "examen",            // Fecha de exámenes
    "acto_escolar",      // Acto escolar
    "reunion_padres",    // Reunión de padres
    "jornada_pedagogica", // Jornada pedagógica (sin clases)
    "otro"               // Otro evento
  ]).notNull(),
  startDate: timestamp("startDate").notNull(),
  endDate: timestamp("endDate").notNull(),
  affectsAttendance: boolean("affectsAttendance").default(true), // Si afecta el cálculo de ausentismo
  courseId: int("courseId").references(() => courses.id), // null = aplica a toda la escuela
  color: varchar("color", { length: 20 }).default("#3b82f6"), // Color para visualización
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy").references(() => users.id),
});

export type AcademicEvent = typeof academicEvents.$inferSelect;
export type InsertAcademicEvent = typeof academicEvents.$inferInsert;
